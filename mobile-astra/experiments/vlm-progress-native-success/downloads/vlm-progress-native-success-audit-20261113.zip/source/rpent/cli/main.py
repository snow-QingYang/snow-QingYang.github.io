# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Physical agent main CLI entrypoint."""

# `rpent/cli/`
#
# CLI entrypoints for RPent (currently just `main.py`).
#
# ## Run
#
# `main()` is exposed as the `rpent` console script (see `[project.scripts]`
# in `pyproject.toml`):
#
# ```bash
# rpent --robot libero --suite libero_object_task --task 0 --seed 0 [...]
# ```
#
# ## Note
#
# Do not import `rpent.cli` from other `rpent` modules. `main.py` pulls in
# `rpent.planner`, `rpent.robots`, `rpent.utils`, `rpent.dashboard`, and
# `rpent.tools`, so importing the CLI back into any of them would create an
# import cycle. Nothing else should depend on this package.
from __future__ import annotations

import argparse
import json
import queue
import shlex
import sys
import time
from collections.abc import Callable
from pathlib import Path

from rpent.cli.tui import (
    start_first_prompt_resolver,
    start_interactive_reader,
)
from rpent.dashboard.events import (
    NullDashboardEventSink,
    RunStartedEvent,
)
from rpent.evaluation import RunFinalizationContext
from rpent.memory import MemoryManager
from rpent.planner.base import (
    REASONING_EFFORTS,
    build_planner,
    is_recoverable_agent_error,
)
from rpent.planner.check import BASE_URL_ENV_BY_PLANNER
from rpent.robots import enumerate_robots, get_robot_spec, get_toolkit
from rpent.utils.logging import get_logger, init_output_dir

logger = get_logger("agent")


# ---------------------------------------------------------------------------
# API agent transcript serialization
# ---------------------------------------------------------------------------


def _strip_images(value):
    """Return a copy of ``value`` with inline image payloads omitted.

    SDK objects are left untouched; ``json.dump(..., default=str)`` handles
    them at write time. Only the bulky base64 image blocks are replaced.
    """
    if isinstance(value, list):
        return [_strip_images(v) for v in value]
    if isinstance(value, dict):
        if value.get("type") == "image":
            return {"type": "image", "source": {"_omitted_for_transcript": True}}
        if value.get("type") == "image_url":
            return {"type": "image_url", "image_url": {"_omitted_for_transcript": True}}
        return {k: _strip_images(v) for k, v in value.items()}
    return value


def _serialize_messages(messages: list[dict]) -> list[dict]:
    """Strip inline image payloads from messages before writing the transcript."""
    return [
        {
            **{k: v for k, v in m.items() if k != "content"},
            "content": _strip_images(m.get("content")),
        }
        for m in messages
    ]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _build_argparser() -> argparse.ArgumentParser:
    known_robots = enumerate_robots()
    known_robots_text = ", ".join(known_robots) if known_robots else "none"
    ap = argparse.ArgumentParser(
        description="RPent: Agentic Infrastructure for the Physical World",
        epilog="To verify the LLM backend before starting a run, use "
        "rpent-check-llm (e.g. rpent-check-llm --planner api "
        "--model anthropic:claude-opus-4-8).",
        add_help=False,
    )

    ap.add_argument(
        "--robot",
        dest="robot_name",
        required=False,
        choices=known_robots,
        help=f"Robot backend. Known robots: {known_robots_text}.",
    )
    ap.add_argument(
        "--env",
        dest="env_name",
        required=False,
        choices=known_robots,
        help="Deprecated alias for --robot; use --robot instead.",
    )

    # models
    ap.add_argument(
        "--planner",
        default="api",
        choices=["api", "claude_code", "codex", "flash"],
        help="Planner backend: api | claude_code | codex are LLMs in the "
        "loop; flash is evaluation-only and replays a plan from memory, re-localizing "
        "each waypoint's anchor.",
    )
    ap.add_argument(
        "--model",
        default=None,
        help="Model id. For the 'api' planner, prefix the provider "
        "(e.g. anthropic:claude-opus-4-8, openai:gpt-5.5, "
        "openai-chat:glm-5.2). For claude_code/codex this "
        "overrides the backend default model.",
    )
    ap.add_argument(
        "--base-url",
        default=None,
        help=(
            "API base URL, for the 'api' planner only. claude_code and codex take their endpoint from ANTHROPIC_BASE_URL / CODEX_BASE_URL instead; passing this flag with either is an error rather than a silent no-op."
        ),
    )
    ap.add_argument("--max-turns", type=int, default=100)
    ap.add_argument("--max-tokens", type=int, default=8192)
    ap.add_argument(
        "--reasoning-effort",
        choices=REASONING_EFFORTS,
        default="none",
        help="Planner reasoning effort for api, claude_code, and "
        "codex. Higher effort may improve task success rate "
        "but increases runtime. Defaults to high for api and none for "
        "claude_code/codex.",
    )
    ap.add_argument(
        "--no-images",
        action="store_true",
        help="Never send image bytes to the model (api planner only). "
        "Use for text-only models that reject image input "
        "(e.g. 400 \"message type 'image_url' is not supported\"); "
        "read_image then returns the image name instead, with a notice.",
    )
    ap.add_argument(
        "--planner-timeout-s",
        type=int,
        default=None,
        help="Wall-clock cap for api/claude_code/codex planner runs. "
        "Terminal interactive API/Claude sessions are exempt. "
        "Defaults to CODEX_TIMEOUT_S (codex only), "
        "CELL_TIMEOUT_S, or 1200.",
    )
    ap.add_argument(
        "--claude-code-max-budget-usd",
        type=float,
        default=None,
        help="Budget passed to claude -p --max-budget-usd. "
        "Defaults to MAX_BUDGET_USD env or 10.",
    )

    # other config
    ap.add_argument("--output-dir", default=None)
    ap.add_argument(
        "--memory-profile",
        choices=["hf", "local"],
        default=None,
        help="Memory profile (default: hf for evaluation, local for exploration).",
    )
    ap.add_argument(
        "--memory-dir",
        default=None,
        help="Local memory root (environment default when omitted).",
    )
    ap.add_argument(
        "--memory-repo",
        default=None,
        help="HF dataset owner/repo or https://huggingface.co/datasets/owner/repo@revision.",
    )
    ap.add_argument(
        "--explore",
        action="store_true",
        help="Enable exploration and memory distillation.",
    )
    ap.add_argument(
        "--dashboard",
        action="store_true",
        help="Start a long-lived local Dashboard Session. Session settings "
        "are read from the CLI.",
    )
    ap.add_argument(
        "--dashboard-host",
        default="127.0.0.1",
        help="Dashboard bind host. Defaults to 127.0.0.1.",
    )
    ap.add_argument(
        "--dashboard-port",
        type=int,
        default=0,
        help="Dashboard port. 0 asks the OS for a free port.",
    )
    ap.add_argument(
        "--dashboard-language",
        choices=["en", "zh-cn"],
        default="en",
        help="Dashboard UI language. 'zh-cn' serves the Chinese "
        "translation; defaults to English.",
    )
    ap.add_argument(
        "--verbose",
        action="store_true",
        help="Enable DEBUG-level logging for stdout and the run.log "
        "file. Defaults to INFO when not set.",
    )
    ap.add_argument(
        "--tui",
        "-t",
        action="store_true",
        help="TUI mode: opens an interactive cli session.",
    )
    # Deprecated alias for --tui; hidden from --help. Kept so existing
    # scripts keep working until the flag is removed.
    ap.add_argument(
        "--interactive",
        "-i",
        dest="tui",
        action="store_true",
        help=argparse.SUPPRESS,
    )

    return ap


def _handoff_message(
    output_dir,
    session_number: int,
    session_max: int,
    *,
    robot_name: str,
) -> str:
    """Build the opening message for a continuation session."""
    attempts_dir = Path(output_dir) / "attempts"
    prior = (
        sorted(p.name for p in attempts_dir.glob("attempt_*_failed.json"))
        if attempts_dir.is_dir()
        else []
    )
    spec = get_robot_spec(robot_name)
    if spec.is_real_robot:
        reset_note = (
            "This is a real-robot continuation: the physical scene is not "
            "automatically reset by toolkit construction. If a restored scene "
            "is required, request operator-mediated scene restoration through "
            "the exposed tools. Wait for the operator to secure held objects "
            "and confirm the scene is safe before the robot resets its posture. "
            "If no such tool is available, stop and ask the operator; do not "
            "substitute a robot-only reset for scene restoration."
        )
    else:
        reset_note = "A fresh toolkit has already restored a clean scene; inspect it before acting."
    return (
        f"You are agent {session_number} of up to {session_max} on this cell. "
        f"{len(prior)} attempt(s) by earlier agents are archived in "
        f"{attempts_dir}/ ({', '.join(prior) if prior else 'none yet'}), and their "
        "working notes are in the memory inbox under wip/.\n\n"
        "Read every archive and the working notes before acting. Do not repeat "
        f"failed approaches. {reset_note}"
    )


def _start_continuation_session(
    args,
    *,
    output_dir,
    recipe_tag,
    dashboard_events,
    prompt_bundle,
    prompt_vars,
    session_number: int,
    session_max: int,
):
    """Build a fresh planner and prompts for an exploration handoff."""
    logger.info("=== handing off to agent %d/%d ===", session_number, session_max)
    planner = build_planner(
        args.planner,
        output_dir=output_dir,
        recipe_tag=recipe_tag,
        robot_name=args.robot_name,
        base_url=args.base_url,
        model=args.model,
        max_tokens=args.max_tokens,
        planner_timeout_s=args.planner_timeout_s,
        reasoning_effort=args.reasoning_effort,
        claude_code_max_budget_usd=args.claude_code_max_budget_usd,
        dashboard_events=dashboard_events,
        no_images=args.no_images,
        interactive=args.tui,
    )
    system_prompt = prompt_bundle.render(
        "system",
        variables={
            **prompt_vars,
            "session_number": session_number,
            "session_max": session_max,
        },
    )
    session_message = _handoff_message(
        output_dir,
        session_number,
        session_max,
        robot_name=args.robot_name,
    )
    if prompt_vars.get("initial_user_message"):
        session_message += "\n\nOriginal operator task instruction:\n" + str(
            prompt_vars["initial_user_message"]
        )
    return planner, system_prompt, session_message


def main() -> int:
    parser = _build_argparser()
    # Two-phase argparse: first grab --robot / --env / --dashboard so we know
    # which robot's flags to add and whether to make its required flags optional.
    early, _ = parser.parse_known_args()
    parser.set_defaults(reasoning_effort="high" if early.planner == "api" else "none")

    # --env is a deprecated alias for --robot; resolve it before loading the spec.
    if early.env_name is not None:
        if early.robot_name is not None:
            parser.error("--robot and --env are aliases; provide only one of them")
        logger.warning("--env is deprecated and will be removed; use --robot instead")
        early.robot_name = early.env_name
    if early.robot_name is None:
        if "-h" not in sys.argv and "--help" not in sys.argv:
            parser.error("--robot is required")
    else:
        robot_spec = get_robot_spec(early.robot_name)
        robot_spec.add_cli_args(parser, use_dashboard=early.dashboard)
    parser.add_argument(
        "-h",
        "--help",
        action="help",
        default=argparse.SUPPRESS,
        help="show this help message and exit",
    )
    args = parser.parse_args()
    args.robot_name = early.robot_name
    if "--interactive" in sys.argv or "-i" in sys.argv:
        logger.warning("--interactive is deprecated; use --tui instead")
    human_interactive_exploration = (
        args.explore and robot_spec.supports_human_interactive_exploration
    )
    if args.dashboard and args.tui:
        parser.error("--dashboard and --tui cannot be used together")
    external_env_dashboard = (getattr(robot_spec, "dashboard", None) or {}).get(
        "external_env", False
    )
    if robot_spec.is_real_robot and not (
        human_interactive_exploration
        or external_env_dashboard
        or (args.dashboard and robot_spec.supports_human_interactive_exploration)
    ):
        if args.dashboard or args.tui:
            option = "--dashboard" if args.dashboard else "--tui"
            guidance = "Run in a plain terminal for operator confirmation."
            if robot_spec.supports_human_interactive_exploration:
                guidance += " Alternatively, use --dashboard."
            parser.error(
                f"{option} is not supported for this robot in the current mode. "
                + guidance
            )
        if sys.stdin is None or not sys.stdin.isatty():
            parser.error("This robot requires a TTY for operator confirmation.")
    native_cli = args.tui and args.planner == "api"
    if args.base_url and args.planner in BASE_URL_ENV_BY_PLANNER:
        parser.error(
            "--base-url applies to the 'api' planner only; "
            f"{args.planner} reads its endpoint from "
            f"{BASE_URL_ENV_BY_PLANNER[args.planner]} instead"
        )
    if args.planner == "flash":
        if args.explore:
            parser.error("Flash Mode is evaluation-only; remove --explore")
        if robot_spec.run_flash is None:
            parser.error(f"Flash Mode is not supported for robot {args.robot_name!r}")
    if args.explore and not robot_spec.supports_exploration:
        detail = (
            " Real-robot exploration requires operator-mediated scene restoration "
            "and feedback support."
            if robot_spec.is_real_robot
            else ""
        )
        parser.error(
            f"--explore is not supported for robot {args.robot_name!r}.{detail}"
        )
    if args.explore and getattr(args, "explore_attempts_per_session", 0) < 0:
        parser.error("--explore-attempts-per-session must be nonnegative")
    if human_interactive_exploration and not args.dashboard:
        if sys.stdin is None or not sys.stdin.isatty():
            parser.error(
                "Human-interactive exploration requires a TTY for operator reset/verdict feedback"
            )
    if args.explore and args.memory_profile == "hf":
        parser.error("--explore cannot be used with --memory-profile hf")
    if args.explore and getattr(args, "explore_sessions", 1) <= 0:
        parser.error("--explore-sessions must be greater than 0")
    args.memory_profile = args.memory_profile or ("local" if args.explore else "hf")
    if args.memory_profile == "hf" and args.memory_dir is not None:
        parser.error("--memory-dir requires --memory-profile local or --explore")
    if args.memory_repo is not None and args.memory_profile == "local":
        parser.error("--memory-repo requires HF evaluation")
    from rpent.memory.loading import prepare_run_memory

    try:
        if args.memory_repo is not None:
            from rpent.memory.source import parse_repo

            parse_repo(args.memory_repo)
        if robot_spec.validate_args is not None:
            robot_spec.validate_args(args)
    except ValueError as exc:
        parser.error(str(exc))
    if args.dashboard:
        from rpent.cli.dashboard import run_dashboard_session

        return run_dashboard_session(args, robot_spec, parser=parser)

    try:
        run_config = robot_spec.parse_config(args)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    recipe_tag = run_config.recipe_tag
    output_dir = run_config.output_dir
    prompt_vars = run_config.prompt_vars
    task_desc = run_config.task_desc

    robot_name = args.robot_name

    # mkdir + logging wiring (robot-side already picked the path).
    output_dir = init_output_dir(output_dir, verbose=args.verbose)
    logger.info("physical agent cmd: %s", shlex.join([sys.executable, *sys.argv]))

    prepare_run_memory(args, robot_spec, run_config)

    dashboard_events = NullDashboardEventSink()

    planner = build_planner(
        args.planner,
        output_dir=output_dir,
        recipe_tag=recipe_tag,
        robot_name=robot_name,
        memory_dir=prompt_vars.get("memory_dir"),
        base_url=args.base_url,
        model=args.model,
        max_tokens=args.max_tokens,
        planner_timeout_s=args.planner_timeout_s,
        reasoning_effort=args.reasoning_effort,
        claude_code_max_budget_usd=args.claude_code_max_budget_usd,
        dashboard_events=dashboard_events,
        no_images=args.no_images,
        interactive=args.tui,
    )
    prompt_bundle = robot_spec.prompts
    prompt_vars = {**prompt_vars, "output_dir": output_dir}
    system_prompt = prompt_bundle.render(
        "system",
        variables=prompt_vars,
    )
    user_msg = prompt_bundle.render(
        "user",
        variables=prompt_vars,
    )

    operator_input = None
    if human_interactive_exploration:
        from rpent.tools.human_in_the_loop import HumanInTheLoopInput

        # The native CLI reads between runs, leaving the TTY available to tools.
        operator_input = HumanInTheLoopInput(interactive=args.tui and not native_cli)
    input_queue: "queue.Queue[str | None] | None" = None
    await_first_prompt: "Callable[[], str | None] | None" = None
    if args.tui and not native_cli:
        input_queue = queue.Queue()
        # Pre-fill the first prompt with the rendered default task (editable
        # preset);
        start_interactive_reader(
            input_queue,
            first_prompt_default=user_msg,
            **(
                {
                    "line_handler": operator_input.route_line,
                    "extra_help": operator_input.help_text,
                    "on_close": operator_input.close,
                }
                if operator_input is not None
                else {}
            ),
        )
        logger.info(
            "interactive mode on: the built-in task is pre-filled — "
            "edit it and press Enter, submit it as-is, or clear it to "
            "type your own. Once running, type to steer the agent. "
            "/help for commands."
        )
        # Resolve the opening prompt on a background thread so the user can type
        # it while the (slow) env/VLA servers boot below.
        await_first_prompt = start_first_prompt_resolver(input_queue)

    # --- initialise robot runtime --------------------------------------------
    daemons, runtime_kwargs = robot_spec.init_runtime(
        args,
        output_dir,
        dashboard_events,
        None,
    )

    # --- agent loop --------------------------------------------------------
    t0 = time.time()
    finish_result, messages, agent_error = None, [], None
    stats: dict = {}
    first_user_msg: str | None = user_msg
    if await_first_prompt is not None:
        # Block until the opening prompt typed during startup is ready.
        first_user_msg = await_first_prompt()
        if first_user_msg is None:
            logger.info("no task entered; ending session before start.")
    if human_interactive_exploration:
        prompt_vars = {**prompt_vars, "initial_user_message": first_user_msg}
    # Exploration may hand off between independent planner contexts.
    sessions = max(1, int(getattr(args, "explore_sessions", 1) or 1))
    if not getattr(args, "explore", False):
        sessions = 1
    recipe_path = ""
    solved = False
    environment_success: bool | None = None
    memory_manager: MemoryManager | None = None
    try:
        if first_user_msg is not None:
            dashboard_events.emit(RunStartedEvent())
        session_msg = first_user_msg
        for session_number in range(1, sessions + 1):
            if session_msg is None:
                break
            if session_number > 1:
                planner, system_prompt, session_msg = _start_continuation_session(
                    args,
                    output_dir=output_dir,
                    recipe_tag=recipe_tag,
                    dashboard_events=dashboard_events,
                    prompt_bundle=prompt_bundle,
                    prompt_vars=prompt_vars,
                    session_number=session_number,
                    session_max=sessions,
                )
            state_output_dir = output_dir
            if getattr(args, "explore", False):
                state_output_dir = (
                    output_dir / "sessions" / f"session_{session_number:03d}"
                )
            if getattr(robot_spec, "supports_exploration", False):
                toolkit = get_toolkit(
                    robot_name,
                    runtime_kwargs=runtime_kwargs,
                    dashboard_events=dashboard_events,
                    config=run_config,
                    mode="exploration" if args.explore else "evaluation",
                    attempts_per_session=getattr(
                        args, "explore_attempts_per_session", 0
                    ),
                    state_output_dir=state_output_dir,
                    **(
                        {"operator_input": operator_input}
                        if operator_input is not None
                        else {}
                    ),
                )
            else:
                toolkit = get_toolkit(
                    robot_name,
                    runtime_kwargs=runtime_kwargs,
                    dashboard_events=dashboard_events,
                    config=run_config,
                )
            memory_manager = toolkit.memory
            if operator_input is not None and input_queue is not None:

                def accept_verdict(verdict: str, active_toolkit=toolkit) -> bool:
                    if not active_toolkit.request_direct_verdict(verdict):
                        return False
                    logger.info(
                        "/%s accepted: stopping actions, then recording the result and exiting.",
                        verdict,
                    )
                    # EOF is a planner control signal, never a model message.
                    input_queue.put(None)
                    return True

                operator_input.bind_verdict(accept_verdict)
            try:
                result = planner.solve(
                    system_prompt=system_prompt,
                    user_message=session_msg,
                    toolkit=toolkit,
                    max_turns=args.max_turns,
                    input_queue=input_queue,
                )
                finish_result = result.finish_result
                messages += result.messages
                stats = result.stats
                agent_error = result.error
                if getattr(toolkit, "direct_verdict_requested", False):
                    finish_result = toolkit.finalize_direct_verdict()
                    if agent_error:
                        logger.info(
                            "Planner stopped after operator verdict: %s", agent_error
                        )
                        stats["planner_error_at_operator_verdict"] = agent_error
                solved_fn = getattr(toolkit, "solved", None)
                if getattr(robot_spec, "supports_exploration", False) and callable(
                    solved_fn
                ):
                    solved = bool(solved_fn())
                    write_recipe = getattr(toolkit, "write_recipe", None)
                    if solved and callable(write_recipe):
                        recipe_path = write_recipe(recipe_tag) or recipe_path
            finally:
                if operator_input is not None and input_queue is not None:
                    operator_input.bind_verdict(None)
                try:
                    if robot_spec.finalize_run is not None:
                        solved_fn = getattr(toolkit, "solved", None)
                        environment_success = (
                            bool(solved_fn()) if callable(solved_fn) else None
                        )
                        solved = bool(environment_success)
                finally:
                    toolkit.close()
            if (
                solved
                or (finish_result or {}).get("operator_aborted")
                or (finish_result or {}).get("operator_finished")
            ):
                break
            if agent_error:
                if (
                    getattr(args, "explore", False)
                    and session_number < sessions
                    and is_recoverable_agent_error(agent_error)
                ):
                    logger.warning(
                        "session %d/%d ended with %s; continuing with a fresh handoff",
                        session_number,
                        sessions,
                        agent_error,
                    )
                    continue
                break
    except Exception as exc:
        agent_error = f"{type(exc).__name__}: {exc}"
        logger.error("EXCEPTION in agent loop: %s", agent_error)
    finally:
        if operator_input is not None:
            operator_input.close()
        if recipe_path:
            logger.info("recipe: %s", recipe_path)
        else:
            logger.info("recipe: not written (cell unsolved)")
        for d in daemons:
            d.stop()

    elapsed = time.time() - t0

    transcript_path = Path(output_dir) / f"transcript_{recipe_tag}.json"
    record = {
        **task_desc,
        "model": args.model,
        "elapsed_s": round(elapsed, 1),
        "finish": finish_result,
        "error": agent_error,
        "environment_success": environment_success,
        "stats": stats,
        "messages": _serialize_messages(messages),
    }
    with open(transcript_path, "a") as f:
        json.dump(record, f, indent=2, default=str)

    logger.info("elapsed: %.1fs", elapsed)
    logger.info(
        "usage: in=%s out=%s tool_calls=%s",
        stats.get("total_input_tokens", "?"),
        stats.get("total_output_tokens", "?"),
        stats.get("tool_calls", "?"),
    )
    logger.info("transcript: %s", transcript_path)

    if robot_spec.finalize_run is not None:
        try:
            result_path = robot_spec.finalize_run(
                RunFinalizationContext(
                    output_dir=Path(output_dir),
                    robot_name=robot_name,
                    task_desc=dict(task_desc),
                    environment_success=environment_success,
                    agent_error=agent_error,
                    elapsed_s=elapsed,
                    planner=args.planner,
                    model=args.model,
                    reasoning_effort=args.reasoning_effort,
                    max_turns=args.max_turns,
                    planner_timeout_s=args.planner_timeout_s,
                    finish_result=(
                        dict(finish_result) if finish_result is not None else None
                    ),
                    stats=dict(stats),
                )
            )
            if result_path:
                logger.info("run result: %s", result_path)
        except Exception as exc:
            agent_error = f"result finalization failed: {type(exc).__name__}: {exc}"
            logger.error("%s", agent_error)

    # Publish exploration artifacts into the corpus after the session loop.
    if (
        getattr(args, "explore", False)
        and getattr(args, "auto_merge_memory", False)
        and not agent_error
        and not (finish_result or {}).get("operator_aborted")
        and memory_manager is not None
    ):
        try:
            merge_result = memory_manager.merge_memory(
                cell_tag=run_config.recipe_tag,
                run_state_dir=run_config.output_dir,
                solved=solved,
            )
            if merge_result:
                logger.info("memory merged: %s", merge_result)
        except Exception as exc:
            agent_error = f"memory finalization failed: {type(exc).__name__}: {exc}"
            logger.error("%s", agent_error)

    return 1 if agent_error else 0


if __name__ == "__main__":
    sys.exit(main())
