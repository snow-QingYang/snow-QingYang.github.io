# E10: VLM task progress with native success

160 valid episodes: Seen 26/80, Unseen 18/80, total 44/160 (27.50%).
Final scores use simulator truth. VLM supplies intermediate progress only.
Full condition definitions and runtime source are under source/.
analysis/ contains the portable extractor, comparisons and report.
SHA256SUMS.json hashes the uncompressed archive members.

This PUBLIC AUDIT archive contains all 160 result/native state/memory audit files and all VLM judgments/request audits, with machine paths replaced. Production source is byte-identical. It omits raw planner transcripts/streams, images, videos, depth/world maps, operator logs, credentials, checkpoints and the memory corpus. The full local ZIP retains those episode artifacts.
