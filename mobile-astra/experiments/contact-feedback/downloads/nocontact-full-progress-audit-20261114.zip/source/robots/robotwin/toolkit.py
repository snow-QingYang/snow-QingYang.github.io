# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""RPent tools for the RLinf RoboTwin robot."""

from __future__ import annotations

from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from robots.robotwin import tools
from robots.robotwin.primitives import RoboTwinPrimitives
from robots.robotwin.robot_spec import ROBOTWIN_CAMERA_NAMES
from rpent.dashboard.events import DashboardEventSink
from rpent.session import EnvState
from rpent.tools import ToolResult, iter_tools, tool
from rpent.tools.direct_action import direct_action_tool
from rpent.tools.toolkit import Toolkit
from rpent.utils.logging import get_output_dir

if TYPE_CHECKING:
    from rpent.memory.manager import MemoryManager

# State-advancing RoboTwin primitives eligible for the recipe. ``reset``,
# ``render``, and read-only tools are intentionally excluded so the recipe
# records only commands that actually move the robot.
_RECIPE_ACTIONS = {
    "lingbot_act",
    "execute_action",
    "move_to",
    "rotate_wrist",
    "set_gripper",
    "release",
}


def _world_from_depth(
    depth_metric: np.ndarray, camera_meta: dict[str, Any]
) -> np.ndarray:
    """Back-project metric depth into the RoboTwin world frame."""
    depth = np.asarray(depth_metric, dtype=np.float64)
    if depth.ndim != 2:
        raise ValueError(f"RoboTwin depth must have shape [H,W], got {depth.shape}")

    intrinsic = np.asarray(camera_meta.get("intrinsic_K"), dtype=np.float64)
    cam2world = np.asarray(camera_meta.get("cam2world_gl"), dtype=np.float64)
    if intrinsic.shape != (3, 3):
        raise ValueError("RoboTwin camera intrinsic_K must have shape (3,3)")
    if cam2world.shape != (4, 4):
        raise ValueError("RoboTwin camera cam2world_gl must have shape (4,4)")
    if not np.isfinite(intrinsic).all() or not np.isfinite(cam2world).all():
        raise ValueError("RoboTwin camera calibration must contain only finite values")

    height, width = depth.shape
    if camera_meta.get("height") != height or camera_meta.get("width") != width:
        raise ValueError(
            "RoboTwin depth shape does not match camera metadata: "
            f"depth={depth.shape}, metadata="
            f"({camera_meta.get('height')}, {camera_meta.get('width')})"
        )
    fx, fy = intrinsic[0, 0], intrinsic[1, 1]
    cx, cy = intrinsic[0, 2], intrinsic[1, 2]
    rows, cols = np.mgrid[0:height, 0:width]
    camera_points = np.stack(
        [
            (cols - cx) * depth / fx,
            -(rows - cy) * depth / fy,
            -depth,
        ],
        axis=-1,
    )
    world = camera_points @ cam2world[:3, :3].T + cam2world[:3, 3]
    return world.astype(np.float32)


class RoboTwinToolkit(Toolkit):
    """Common RPent tools plus RoboTwin primitives."""

    def __init__(
        self,
        *,
        runtime_kwargs: dict[str, Any],
        dashboard_events: DashboardEventSink,
        memory: MemoryManager,
        enable_direct_action: bool = False,
        mode: str = "evaluation",
        attempts_per_session: int = 0,
        state_output_dir: Path | str | None = None,
    ):
        if mode not in {"evaluation", "exploration"}:
            raise ValueError(f"unsupported RoboTwin toolkit mode: {mode!r}")
        state = EnvState(Path(state_output_dir or get_output_dir()))
        super().__init__(
            dashboard_events=dashboard_events,
            state=state,
            memory=memory,
        )
        self._mode = mode
        self._attempt = 1
        self._attempts_per_session = max(0, int(attempts_per_session))
        self._latest_status: dict[str, Any] = {}
        self._primitives = RoboTwinPrimitives(
            check_cancelled=self.raise_if_cancelled,
            **runtime_kwargs,
        )
        if self._mode == "exploration":
            reset_result = self._primitives.reset()
        else:
            reset_result = {
                **self._primitives.env.last_reset_info,
                "success": True,
            }
        self._primitives.start_recording()
        self._action_frame_cursor = self._primitives.recorded_frame_count()
        self._register_robotwin_tools()
        if enable_direct_action:
            self.add_tool(
                direct_action_tool(
                    self._primitives.env.action_specs,
                    partial(self._step, "execute_action"),
                )
            )
        initial = self.get_env_state(
            command={"action": "reset"},
            result=reset_result,
            elapsed_s=0.0,
        )
        record = self._state.latest_record()
        if record is not None:
            self._publish_step(record)
        initial_state = initial.data.get("state")
        if isinstance(initial_state, dict):
            self._latest_status = initial_state.get(
                "episode_status", self._latest_status
            )

    def _register_robotwin_tools(self) -> None:
        for definition in iter_tools(tools):
            if definition.name == "view_env_state":
                handler = partial(definition, state=self._state)
            else:
                handler = partial(definition, self._state)
            self.add_tool(definition.with_handler(handler))
        for definition in iter_tools(self._primitives):
            handler = (
                definition
                if definition.name == "finish"
                else partial(self._step, definition.name)
            )
            self.add_tool(
                definition.with_handler(handler), replace=definition.name == "finish"
            )
        self.add_tool(self.render)
        if self._mode == "exploration":
            self.add_tool(
                self._primitives.finish.with_handler(self._guarded_finish), replace=True
            )
            self.add_tool(self._reset_episode)

    @tool
    def render(self) -> ToolResult:
        """Capture a fresh synchronized RoboTwin agent observation."""
        self.raise_if_cancelled()
        return ToolResult(data={"success": True})

    def _guarded_finish(self, *, status: str, summary: str) -> ToolResult:
        budget = self._attempts_per_session
        if budget and not self.solved() and self._attempt < budget:
            payload = {
                "error": "finish refused",
                "reason": (
                    f"This session has {budget - self._attempt} of its {budget} "
                    "attempts left. Archive the attempt, reset, and change the plan."
                ),
            }
            return ToolResult(data=payload)
        return self._primitives.finish(status=status, summary=summary)

    @tool(name="reset")
    def _reset_episode(self) -> ToolResult:
        """Restart the episode for a fresh exploration attempt. Available only in explore mode. Re-run perception after every reset."""
        if self.solved():
            payload = {
                "error": "reset refused",
                "reason": "The task is already solved; save artifacts and finish.",
            }
            return ToolResult(data=payload)
        budget = self._attempts_per_session
        if budget and self._attempt >= budget:
            payload = {
                "error": "reset refused",
                "reason": (
                    f"This session's attempt budget is spent ({budget} attempts). "
                    "Update the handoff notes and finish this session."
                ),
            }
            return ToolResult(data=payload)
        result = self._primitives.reset()
        if result.get("error") or result.get("success") is False:
            payload = result
            return ToolResult(data=payload)
        self._attempt += 1
        payload = {
            **result,
            "attempt": self._attempt,
            "notice": "Fresh episode started. Re-run perception before acting.",
        }
        return ToolResult(data=payload)

    def _capture_full_observation(self) -> dict[str, Any]:
        """Assemble the full observation (rgb + depth + camera_meta + world_xyz).

        This is the dump/recording path consumed by ``tools.dump_observation``
        and the ``sample_world_xyz`` agent tool. It deliberately fetches depth
        and camera_meta so ``world_xyz`` can be back-projected and saved as an
        artifact -- distinct from the rgb-only observation built for LingBot
        inference in ``RoboTwinPrimitives._build_lingbot_observation``.
        """
        env = self._primitives.env
        views: dict[str, dict[str, Any]] = {}
        for camera_name in ROBOTWIN_CAMERA_NAMES:
            rendered = env.render_camera(camera_name, depth=True)
            if not isinstance(rendered, (list, tuple)) or len(rendered) != 2:
                raise TypeError(
                    "RoboTwin render_camera(depth=True) must return (rgb, depth)"
                )
            rgb, depth = rendered
            camera_meta = env.get_camera_meta(camera_name)
            views[camera_name] = {
                "rgb": np.asarray(rgb),
                "depth": np.asarray(depth, dtype=np.float32),
                "world_xyz": _world_from_depth(depth, camera_meta),
                "camera_meta": camera_meta,
            }
        return {
            "views": views,
            "robot_state": env.last_info["robot_state"],
            "task_name": env.server_meta["task_name"],
            "task_language": env.get_task_language(),
            "depth_unit": "metres",
            "world_frame": "world",
        }

    def get_env_state(
        self,
        *,
        command: dict[str, Any],
        result: dict[str, Any],
        elapsed_s: float,
    ) -> ToolResult:
        frame_start = self._action_frame_cursor
        self._action_frame_cursor = self._primitives.recorded_frame_count()
        status = self._primitives.status()
        self._latest_status = status
        observation = self._capture_full_observation()
        record = tools.dump_observation(
            observation,
            env_state=self._state,
            status=status,
            log={
                "command": command,
                "result": result,
                "elapsed_s": elapsed_s,
            },
        )
        if self._dashboard_events.enabled:
            frames = self._primitives.frame_slice(frame_start)
            if frames:
                self._state.save(
                    f"action_{command['action']}.mp4",
                    frames,
                    step=record.step_idx,
                    fps=20,
                )
        return tools.view_env_state(record.step_idx, state=self._state)

    def close(self) -> None:
        """Flush the per-step frame buffer into ``episode.mp4`` (LIBERO parity)."""
        super().close()
        frames = self._primitives.stop_recording()
        if frames:
            self._state.save("episode.mp4", frames, step=None, fps=20)

    def solved(self) -> bool:
        """Return the native RoboTwin task success flag."""
        return self._primitives.status().get("eval_success") is True

    def _step(self, name: str, **kwargs) -> ToolResult:

        self.raise_if_cancelled()
        return getattr(self._primitives, name)(**kwargs)

    def write_recipe(self, recipe_tag: str) -> str:
        """Export state-advancing RoboTwin primitives with no error and no
        explicit ``success=False`` from ``EnvState.records()``."""
        records = self._state.records()
        if self._mode == "exploration":
            if not self.solved():
                return ""
            last_reset = max(
                (
                    record.step_idx
                    for record in records
                    if isinstance(record.command, dict)
                    and record.command.get("action") == "reset"
                    and not (
                        isinstance(record.result, dict) and record.result.get("error")
                    )
                ),
                default=-1,
            )
            records = [record for record in records if record.step_idx > last_reset]
            if not any(record.terminated for record in records):
                return ""
        recipe = [
            record.command
            for record in records
            if isinstance(record.command, dict)
            and record.command.get("action") in _RECIPE_ACTIONS
            and not (
                isinstance(record.result, dict)
                and (
                    record.result.get("error") or record.result.get("success") is False
                )
            )
        ]
        name = f"{recipe_tag}_recipe.jsonl"
        destination = (
            EnvState(Path(get_output_dir()))
            if self._mode == "exploration"
            else self._state
        )
        saved = destination.save(name, recipe, step=None)
        if saved is None:
            raise RuntimeError(f"failed to save RoboTwin recipe artifact: {name}")
        return str(destination.artifact_path(name, step=None))
