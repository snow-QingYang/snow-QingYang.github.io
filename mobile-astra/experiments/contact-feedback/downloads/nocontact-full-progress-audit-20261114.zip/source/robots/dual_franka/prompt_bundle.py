# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Prompt bundle assembly for the dual-Franka environment."""

from __future__ import annotations

from collections.abc import Mapping

from robots.dual_franka.prompts import explore as explore_parts
from robots.dual_franka.prompts import system as system_parts
from robots.dual_franka.prompts import user as user_parts
from rpent.prompt.utils import Numbered, PromptNode


def system_prompt(variables: Mapping[str, object] | None = None) -> PromptNode:
    """Assemble the dual-Franka system prompt."""
    if (variables or {}).get("mode") == "explore":
        return explore_parts.system_prompt()
    node: dict[str, object] = {
        "ROLE": system_parts.ROLE,
        "RUNTIME": system_parts.RUNTIME,
        "SAFETY RULES": Numbered(system_parts.RULES),
        "CAMERA AND PROJECTION RULES": Numbered(system_parts.CAMERA_AND_PROJECTION),
        "VLA SEGMENT GATES": Numbered(system_parts.VLA_GATES),
        "WORKFLOW": Numbered(system_parts.WORKFLOW),
    }
    return node


def user_prompt(variables: Mapping[str, object] | None = None) -> PromptNode:
    """Assemble the task-specific initial user prompt."""
    node: dict[str, object] = {
        "TASK": user_parts.TASK,
        "TASK CONSTRAINTS": user_parts.CONSTRAINTS,
        "BEGIN": explore_parts.BEGIN
        if (variables or {}).get("mode") == "explore"
        else user_parts.BEGIN,
    }
    if (variables or {}).get("mode") == "explore":
        node["EXPLORATION OUTPUT"] = (
            "Use {{memory_inbox}} for reviewable exploration notes and "
            "{{output_dir}}/attempts/ for failed-attempt archives."
        )
    return node
