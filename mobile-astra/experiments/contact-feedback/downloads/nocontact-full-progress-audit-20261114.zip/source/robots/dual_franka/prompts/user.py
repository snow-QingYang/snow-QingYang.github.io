# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""User prompt sections for one dual-Franka task run."""

TASK = """- task_name: {{task_name}}
- instruction: {{instruction}}
- initial_setup: {{setup}}
- success_criteria: {{success_criteria}}"""

CONSTRAINTS = """{{constraints}}"""

BEGIN = """Call describe_dual_franka_setup, then request_scene_reset before acting.
After operator confirmation and a successful reset, inspect the fresh visual evidence
together with both arms' TCP/gripper/joint-health state, and execute the task
conservatively with the exposed bounded tools. Auxiliary camera views are
artifact views for targeted follow-up inspection only."""
