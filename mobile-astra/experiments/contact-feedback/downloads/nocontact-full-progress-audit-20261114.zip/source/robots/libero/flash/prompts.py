# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Visual-grounding queries used at each stage of Flash Mode replay.

The object noun comes from the program. These templates add only the spatial or
visual context needed by each localization stage.
"""

PROMPTS = {
    # Opening survey from the fixed camera.
    "survey": "{object}",
    # Close refinement from the wrist camera with the arm above the object.
    "refine": "the center of the {object} directly below the gripper",
    # Object currently held by the gripper.
    "held": "the body of the {object} held in the gripper",
}


def build(situation: str, obj: str) -> str:
    return PROMPTS[situation].format(object=obj)
