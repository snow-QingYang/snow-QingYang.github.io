# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""User prompt section bodies for a concrete LIBERO evaluation cell."""

from __future__ import annotations

CELL = """- suite:      {{suite}}
- task:       {{task}}
- seed:       {{seed}}
- output_dir: {{output_dir}}
- audit:      {{output_dir}}/{{recipe_tag}}.json
- recipe:     {{output_dir}}/{{recipe_tag}}_recipe.jsonl"""


MODE = """Inspect `agentview_high.png` returned by `view_env_state`, then use
`back_project` or `segment` to localize objects before motion."""


BEGIN = """Read the guides, then call `view_env_state({"step": 0})` and inspect
`task_language` and `agentview_high.png`. Read matching memory and available
seed-0 references for the current task and scene, then localize, plan, and execute."""
