# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LIBERO + OpenPI tool implementation."""

from __future__ import annotations

import json
import threading
from collections.abc import Callable
from pathlib import Path
from typing import Annotated, Any, Literal

import numpy as np
from pydantic import Field

from robots.libero.env_client import LiberoEnvClient
from rpent.robots.components.molmo_client import MolmoClient
from rpent.robots.components.pi05_vla_client import Pi05VLAClient
from rpent.robots.components.sam3_client import Sam3Client
from rpent.session import EnvState, StepRecord
from rpent.tools import Tool, ToolResult, tool
from rpent.utils.logging import get_logger

logger = get_logger("libero_tools")


def _normalize_xyz(xyz):
    """Coerce an LLM-supplied xyz into a length-3 list[float]."""
    if not isinstance(xyz, (list, tuple)) or len(xyz) != 3:
        raise ValueError(
            'xyz must be a JSON array of three numbers, e.g. "xyz":[-0.05,0,0.3]'
        )
    return [float(v) for v in xyz]


class LiberoPrimitives:
    """Wraps a single-env LIBERO-shaped env + VLA policy with primitive-
    level methods.

    ``pi0_pick`` and ``pi0_doubled`` override ``obs['task_descriptions']``
    with a sub-instruction. ``move_to`` and friends are scripted (no VLM
    call) and drive the underlying OSC controller directly.
    """

    def __init__(
        self,
        env: LiberoEnvClient,
        model: Pi05VLAClient,
        sam3_client: Sam3Client,
        check_cancelled: Callable[[], None],
        molmo_client: MolmoClient | None = None,
        flywheel_config: dict[str, Any] | None = None,
    ):
        self.env = env
        self.model = model
        self._sam3_client = sam3_client
        self._segment_index_lock = threading.Lock()
        self._segment_index = 0
        #: Only a Flash Mode replay reads this; other runs never start Molmo.
        self.molmo_client = molmo_client
        self._check_cancelled = check_cancelled
        self._last_obs = None
        self._last_obs_eef_pos = None
        self._last_obs_eef_z = None
        self._last_obs_gripper = None
        # Per-env-step frame buffer for diagnostic video rendering.
        # Toggled via start_recording() / stop_recording().
        self._recording = False
        self._frames = []
        self._flywheel_config = flywheel_config
        self._flywheel = None

    def start_recording(self):
        self._recording = True
        self._frames = []

    def record_frame(self, obs):
        """Append one agentview frame extracted from ``obs`` to the buffer."""
        self._frames.append(np.ascontiguousarray(np.asarray(obs["main_images"])))

    def recorded_frame_count(self) -> int:
        return len(self._frames)

    def stop_recording(self) -> list[np.ndarray]:
        frames = list(self._frames)
        self._recording = False
        self._frames = []
        return frames

    def frame_slice(self, start: int) -> list[np.ndarray]:
        return list(self._frames[int(start) :])

    def set_obs(self, obs):
        self._last_obs = obs
        states_arr = np.asarray(obs["states"])
        self._last_obs_eef_pos = np.asarray(states_arr[:3], dtype=np.float32)
        self._last_obs_eef_z = float(self._last_obs_eef_pos[2])
        # robosuite 2f85: qpos[6] in [~0, ~0.04], qpos[7] in [~-0.04, ~0].
        # Use |qpos[6]| + |qpos[7]| ≈ finger separation proxy.
        # When open ≈ 0.08; when closed ≈ 0.
        gp = np.asarray(states_arr[6:8], dtype=np.float32)
        self._last_obs_gripper = float(abs(gp[0]) + abs(gp[1]))

    def reset(self):
        obs, info = self.env.reset()
        self.set_obs(obs)
        if self._flywheel_config is not None:
            from robots.libero.flywheel import create_episode_writer

            self._flywheel = create_episode_writer(self._flywheel_config, obs)
        return self._last_obs, info

    def begin_primitive(self, name: str) -> None:
        if self._flywheel is not None:
            self._flywheel.begin_primitive(name)

    def end_primitive(self) -> None:
        if self._flywheel is not None:
            self._flywheel.end_primitive()

    def finalize_flywheel(self) -> Path | None:
        return self._flywheel.finalize() if self._flywheel is not None else None

    def _step_env(self, action) -> None:
        """Execute one env action between cancellation checkpoints."""
        self._check_cancelled()
        obs, reward, terminated, truncated, _info = self.env.step(action)
        if self._flywheel is not None:
            self._flywheel.add_transition(action, obs, reward, terminated, truncated)
        self.set_obs(obs)
        if self._recording:
            self.record_frame(obs)

    def execute_action(self, values: list[float]) -> ToolResult:
        """Execute one native action and refresh observations and recording."""
        action = self.env.validate_action(values)
        self._step_env(action)
        return ToolResult(data={"executed_steps": 1})

    def reset_episode(self, reason: str = "") -> dict:
        """Restart an episode and return an explore-tool-compatible result."""
        self.reset()
        return {
            "action": "reset",
            "reason": reason,
            "libero_terminated": self.env.terminated or self.env.truncated,
        }

    def _vlm_chunk(self, instruction: str):
        """One model forward + ``chunk_size`` env steps. Overrides prompt."""
        self._check_cancelled()
        original_task = self._last_obs.get("task_descriptions")
        try:
            self._last_obs["task_descriptions"] = instruction
            self._last_obs.setdefault("extra_view_images", None)

            actions = self.model.predict(self._last_obs, options={"mode": "eval"})
            self._check_cancelled()

            vla_id = (
                self._flywheel.add_proposal(instruction, actions)
                if self._flywheel is not None
                else -1
            )

            if not self._recording and self._flywheel is None:
                chunk_obs, _r, _t, _tr, _i = self.env.chunk_step(actions)
                obs = chunk_obs[-1] if self.env.return_all_frames else chunk_obs
            else:
                chunk_obs, rewards, terminated, truncated, _info = self.env.chunk_step(
                    actions, return_all_frames=True
                )
                for index, obs in enumerate(chunk_obs):
                    if self._recording:
                        self.record_frame(obs)
                    if self._flywheel is not None:
                        self._flywheel.add_transition(
                            actions[index],
                            obs,
                            rewards[index],
                            terminated[index],
                            truncated[index],
                            vla_id=vla_id,
                            proposal_index=index,
                        )
                obs = chunk_obs[-1]
            self.set_obs(obs)
            return self._last_obs
        finally:
            if original_task is not None:
                self._last_obs["task_descriptions"] = original_task

    @tool
    def pi0_pick(
        self,
        prompt: str,
        *,
        max_chunks: int = 24,
        lift_thresh: float = 0.05,
        gripper_closed_thresh: float = 0.06,
        gripper_open_thresh: float = 0.0,
        descent_thresh: float = 0.1,
    ) -> ToolResult:
        """Pi0.5 closed-loop pick. Use it for the grasp; YOU then do every move_to and release. Use modest max_chunks and verify the grasp from EEF lift, gripper closure, and available images.

        Args:
            prompt: Pi0 prompt (e.g. 'pick up the akita black bowl').
            max_chunks: Action-chunk budget (default 24)
            lift_thresh: EEF post-descent ascent threshold for success, m (default 0.05)
            gripper_closed_thresh: Finger-separation closed threshold (default 0.06)
            gripper_open_thresh: Minimum finger separation accepted as a held object (default 0.0)
            descent_thresh: Required descent before lift detection, m (default 0.10)
        """
        instr = prompt
        start_z = self._last_obs_eef_z
        peak_z = start_z
        min_z = start_z
        # Track ascent AFTER min_z has been observed — descent then re-ascent
        # is the actual "lift" signal, distinct from raw |peak - min| which
        # also fires at the BOTTOM of the descent.
        post_min_peak_z = start_z
        min_grip = self._last_obs_gripper
        last_grip = min_grip
        descent_done = False
        success = False
        chunks_used = 0

        for c in range(max_chunks):
            self._vlm_chunk(instr)
            chunks_used = c + 1
            z = self._last_obs_eef_z
            grip = self._last_obs_gripper
            peak_z = max(peak_z, z)
            if z < min_z:
                min_z = z
                post_min_peak_z = z  # reset after a new deeper min
            else:
                post_min_peak_z = max(post_min_peak_z, z)
            if (start_z - min_z) >= descent_thresh:
                descent_done = True
            min_grip = min(min_grip, grip)
            last_grip = grip
            ascended = (post_min_peak_z - min_z) >= lift_thresh
            closed = gripper_open_thresh <= grip < gripper_closed_thresh
            if descent_done and ascended and closed:
                success = True
                break
            if self.env.terminated or self.env.truncated:
                success = self.env.terminated
                break

        return ToolResult(
            data={
                "name": "pick",
                "instruction": instr,
                "success": success,
                "chunks_used": chunks_used,
                "max_chunks": max_chunks,
                "peak_lift_m": post_min_peak_z - min_z,
                "min_gripper_opening": min_grip,
                "final_gripper_opening": last_grip,
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
                "diagnostics": {
                    "start_eef_z": round(start_z, 4),
                    "peak_eef_z": round(peak_z, 4),
                    "min_eef_z": round(min_z, 4),
                    "post_min_peak_z": round(post_min_peak_z, 4),
                    "descent_m": round(start_z - min_z, 4),
                    "post_min_ascent_m": round(post_min_peak_z - min_z, 4),
                    "descent_done": descent_done,
                    "lift_thresh": lift_thresh,
                    "gripper_closed_thresh": gripper_closed_thresh,
                    "gripper_open_thresh": gripper_open_thresh,
                    "descent_thresh": descent_thresh,
                },
            }
        )

    @tool
    def pi0_doubled(self, prompt: str, *, max_chunks: int = 20) -> ToolResult:
        """Pi0.5 closed-loop contact skill for non-pick interactions (e.g. stove/knob/button/short push). Returned success/task_success only mirrors official termination; for intermediate contact skills, success=false does not necessarily mean the contact interaction failed. Inspect image/state evidence. Do not use it as a general pick/place shortcut.

        Args:
            prompt: Contact-skill prompt, e.g. 'turn on the stove'.
            max_chunks: Action-chunk budget (default 20)
        """
        instr = prompt
        task_success = False
        chunks_used = 0

        for c in range(max_chunks):
            self._vlm_chunk(instr)
            chunks_used = c + 1
            if self.env.terminated or self.env.truncated:
                task_success = self.env.terminated
                break

        return ToolResult(
            data={
                "name": "pi0_doubled",
                "instruction": instr,
                "success": task_success,
                "task_success": task_success,
                "contact_skill_executed": chunks_used > 0,
                "chunks_used": chunks_used,
                "max_chunks": max_chunks,
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
                "diagnostics": {
                    "mode": "contact_skill_success_by_termination",
                    "success_meaning": "`success` mirrors official LIBERO task termination only; for intermediate contact skills, inspect image/state evidence.",
                },
            }
        )

    @tool
    def move_to(
        self,
        xyz: Annotated[list[float], Field(min_length=3, max_length=3)],
        *,
        max_steps: int = 80,
        gripper: float = -1.0,
        step_clip: float = 0.025,
        tol: float = 0.012,
        action_scale: float = 0.05,
        target_yaw: float | None = None,
        yaw_step_clip: float = 0.1,
        yaw_tol: float = 0.02,
    ) -> ToolResult:
        """Scripted EEF servo to a world-frame XYZ target via the OSC controller. Holds orientation unless target_yaw is supplied; then both position and yaw must converge. Use rotate_pitch or move_pose for pitch changes. gripper: -1 = open, +1 = close. NEVER command a single move_to with |Δxy| > 0.30 — OSC flips IK and the run corrupts; split long traversal into 2-3 mid waypoints at carry z.

        Args:
            xyz: World-frame target [x, y, z] in meters
            gripper: Gripper command: -1 open, +1 close (default -1)
            tol: Position tolerance, m (default 0.012)
            step_clip: Per-step Δxyz cap before action_scale, m (default 0.025)
            max_steps: Step budget (default 80)
            action_scale: OSC action scale (default 0.05)
            target_yaw: Optional world-frame yaw target in radians
            yaw_step_clip: Per-step yaw clip, rad (default 0.10)
            yaw_tol: Positive finite yaw tolerance, rad (default 0.02)
        """
        if not np.isfinite(yaw_tol) or yaw_tol <= 0:
            raise ValueError("yaw_tol must be finite and greater than zero")

        def yaw_error() -> float | ToolResult:
            from scipy.spatial.transform import Rotation as _R

            q = self.env.raw_obs()["robot0_eef_quat"]
            matrix = _R.from_quat(q).as_matrix()
            # The local X axis is unit length. Below a 1e-6 horizontal
            # projection (about 1e-6 rad from vertical), its heading is
            # ill-conditioned; do not feed it to atan2 or claim convergence.
            if np.hypot(matrix[0, 0], matrix[1, 0]) < 1e-6:
                return ToolResult(
                    data={
                        "error": "Cannot control yaw: EEF local X axis is nearly vertical "
                        "(horizontal projection < 1e-6). Reorient the EEF before retrying.",
                        "name": "move_to",
                    }
                )
            # World yaw; Euler zyx reverses its sign for gripper-down poses.
            yaw = float(np.arctan2(matrix[1, 0], matrix[0, 0]))
            return (float(target_yaw) - yaw + np.pi) % (2 * np.pi) - np.pi

        target = np.asarray(_normalize_xyz(xyz), dtype=np.float32)
        traj = []
        for step in range(max_steps):
            cur = self._last_obs_eef_pos
            diff = target - cur
            dist = float(np.linalg.norm(diff))
            traj.append(
                {
                    "step": step,
                    "eef_pos": [round(float(x), 4) for x in cur],
                    "dist_to_target_m": round(dist, 4),
                }
            )
            err = yaw_error() if target_yaw is not None else 0.0
            if isinstance(err, ToolResult):
                return err
            if dist < tol and abs(err) < yaw_tol:
                break
            step_dxyz = np.clip(diff, -step_clip, step_clip)
            action = np.zeros(7, dtype=np.float32)
            action[:3] = step_dxyz / action_scale  # -> roughly [-0.5, 0.5]
            action[:3] = np.clip(action[:3], -1.0, 1.0)
            if target_yaw is not None:
                step_dyaw = float(np.clip(err, -yaw_step_clip, yaw_step_clip))
                action[5] = float(np.clip(step_dyaw / 0.10, -1.0, 1.0))
            action[6] = gripper
            self._step_env(action)
            if self.env.terminated or self.env.truncated:
                break
        final = self._last_obs_eef_pos
        result = ToolResult(
            data={
                "name": "move_to",
                "target_xyz": [float(x) for x in target],
                "final_eef_pos": [round(float(x), 4) for x in final],
                "final_dist_m": round(float(np.linalg.norm(target - final)), 4),
                "steps_used": len(traj),
                "max_steps": max_steps,
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
            }
        )

        if target_yaw is not None:
            err = yaw_error()
            if isinstance(err, ToolResult):
                return err
            result.data["final_yaw_error_rad"] = round(float(err), 4)
        return result

    @tool
    def rotate_wrist(
        self,
        *,
        target_yaw: float | None = None,
        delta_yaw: float | None = None,
        gripper: float = 1.0,
        max_steps: int = 40,
        tol: float = 0.02,
        step_clip: float = 0.1,
        pos_tol: float = 0.03,
    ) -> ToolResult:
        """Rotate the wrist around the world Z-axis. Provide either target_yaw (absolute) or delta_yaw (relative). Holds xyz fixed by servoing back to the entry pose; the result carries converged, position_hold_ok, and max_pos_drift_m.

        Args:
            target_yaw: Absolute world-frame yaw target, rad
            delta_yaw: Relative yaw delta, rad
            gripper: Gripper command held during rotation (default +1)
            max_steps: Step budget (default 40)
            tol: Yaw tolerance, rad (default 0.02)
            step_clip: Per-step yaw clip, rad (default 0.10)
            pos_tol: Position-hold tolerance on max xyz drift, m (default 0.03)
        """
        from scipy.spatial.transform import Rotation as _R

        # LIBERO OSC_POSE scaling: metres/radians per normalized action unit.
        action_scale = 0.05
        rot_scale = 0.5

        def _yaw_of(quat_xyzw):
            # robot0_eef_quat in libero+robosuite is xyzw (scipy convention).
            q = quat_xyzw
            rot = _R.from_quat([q[0], q[1], q[2], q[3]])
            R = rot.as_matrix()
            # World-frame yaw: angle of the eef x-axis projected onto the
            # world xy plane. Robust to gripper-down (R[2,2]≈-1) which is
            # where the euler 'zyx' chart flips sign.
            return float(np.arctan2(R[1, 0], R[0, 0]))

        raw = self.env.raw_obs()
        cur_quat = raw["robot0_eef_quat"]
        start_yaw = _yaw_of(cur_quat)
        if target_yaw is None and delta_yaw is None:
            return ToolResult(
                data={"error": "need target_yaw or delta_yaw", "name": "rotate_wrist"}
            )
        if target_yaw is None:
            target_yaw = start_yaw + float(delta_yaw)
        hold_xyz = np.array(self._last_obs_eef_pos, dtype=np.float32, copy=True)
        max_drift = 0.0

        def _record_drift() -> None:
            nonlocal max_drift
            drift = float(np.linalg.norm(self._last_obs_eef_pos - hold_xyz))
            if drift > max_drift:
                max_drift = drift

        traj = []
        for step in range(max_steps):
            _record_drift()
            raw = self.env.raw_obs()
            cur_yaw = _yaw_of(raw["robot0_eef_quat"])
            err = float(target_yaw - cur_yaw)
            # wrap to [-pi, pi]
            err = (err + np.pi) % (2 * np.pi) - np.pi
            traj.append({"step": step, "yaw": round(cur_yaw, 4), "err": round(err, 4)})
            if abs(err) < tol:
                break
            cur_xyz = self._last_obs_eef_pos
            step_dyaw = float(np.clip(err, -step_clip, step_clip))
            action = np.zeros(7, dtype=np.float32)
            action[:3] = np.clip((hold_xyz - cur_xyz) / action_scale, -1.0, 1.0)
            action[5] = float(np.clip(step_dyaw / rot_scale, -1.0, 1.0))
            action[6] = float(gripper)
            self._step_env(action)
            if self.env.terminated or self.env.truncated:
                break
        final_yaw = _yaw_of(self.env.raw_obs()["robot0_eef_quat"])
        final_err = float((target_yaw - final_yaw + np.pi) % (2 * np.pi) - np.pi)
        _record_drift()
        max_pos_drift_m = round(max_drift, 4)
        return ToolResult(
            data={
                "name": "rotate_wrist",
                "start_yaw": round(start_yaw, 4),
                "target_yaw": round(float(target_yaw), 4),
                "final_yaw": round(final_yaw, 4),
                "final_err": round(final_err, 4),
                "converged": abs(final_err) < tol,
                "max_pos_drift_m": max_pos_drift_m,
                "position_hold_ok": max_pos_drift_m <= pos_tol,
                "steps_used": len(traj),
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
            }
        )

    @tool
    def rotate_pitch(
        self,
        *,
        target_pitch: float | None = None,
        delta_pitch: float | None = None,
        gripper: float = 1.0,
        max_steps: int = 40,
        tol: float = 0.02,
        step_clip: float = 0.1,
        pos_tol: float = 0.03,
    ) -> ToolResult:
        """Tilt the gripper around the world X-axis. Provide either target_pitch (absolute) or delta_pitch (relative). Holds xyz and yaw fixed by servoing back to the entry pose; the result carries converged, position_hold_ok, and max_pos_drift_m. Use before threading the gripper into a narrow opening whose front face normal is along world ±y (e.g. microwave cavity).

        Args:
            target_pitch: Absolute world-frame pitch target, rad
            delta_pitch: Relative pitch delta, rad
            gripper: Gripper command held during rotation (default +1)
            max_steps: Step budget (default 40)
            tol: Pitch tolerance, rad (default 0.02)
            step_clip: Per-step pitch clip, rad (default 0.10)
            pos_tol: Position-hold tolerance on max xyz drift, m (default 0.03)
        """
        from scipy.spatial.transform import Rotation as _R

        # LIBERO OSC_POSE scaling: metres/radians per normalized action unit.
        action_scale = 0.05
        rot_scale = 0.5

        def _pitch_of(quat_xyzw):
            q = quat_xyzw
            R = _R.from_quat([q[0], q[1], q[2], q[3]]).as_matrix()
            return float(np.arctan2(R[1, 2], -R[2, 2]))

        def _yaw_of(quat_xyzw):
            q = quat_xyzw
            R = _R.from_quat([q[0], q[1], q[2], q[3]]).as_matrix()
            return float(np.arctan2(R[1, 0], R[0, 0]))

        raw = self.env.raw_obs()
        start_quat = raw["robot0_eef_quat"]
        start_pitch = _pitch_of(start_quat)
        if target_pitch is None and delta_pitch is None:
            return ToolResult(
                data={
                    "error": "need target_pitch or delta_pitch",
                    "name": "rotate_pitch",
                }
            )
        if target_pitch is None:
            target_pitch = start_pitch + float(delta_pitch)
        start_yaw = _yaw_of(start_quat)
        hold_xyz = np.array(self._last_obs_eef_pos, dtype=np.float32, copy=True)
        max_drift = 0.0

        def _record_drift() -> None:
            nonlocal max_drift
            drift = float(np.linalg.norm(self._last_obs_eef_pos - hold_xyz))
            if drift > max_drift:
                max_drift = drift

        traj = []
        for step in range(max_steps):
            _record_drift()
            raw = self.env.raw_obs()
            cur_quat = raw["robot0_eef_quat"]
            cur_pitch = _pitch_of(cur_quat)
            err = float(target_pitch - cur_pitch)
            err = (err + np.pi) % (2 * np.pi) - np.pi
            traj.append(
                {"step": step, "pitch": round(cur_pitch, 4), "err": round(err, 4)}
            )
            if abs(err) < tol:
                break
            cur_xyz = self._last_obs_eef_pos
            cur_yaw = _yaw_of(cur_quat)
            yaw_err = float((start_yaw - cur_yaw + np.pi) % (2 * np.pi) - np.pi)
            step_dpitch = float(np.clip(err, -step_clip, step_clip))
            step_dyaw = float(np.clip(yaw_err, -step_clip, step_clip))
            action = np.zeros(7, dtype=np.float32)
            action[:3] = np.clip((hold_xyz - cur_xyz) / action_scale, -1.0, 1.0)
            action[3] = float(np.clip(step_dpitch / rot_scale, -1.0, 1.0))
            action[5] = float(np.clip(step_dyaw / rot_scale, -1.0, 1.0))
            action[6] = float(gripper)
            self._step_env(action)
            if self.env.terminated or self.env.truncated:
                break
        final_quat = self.env.raw_obs()["robot0_eef_quat"]
        final_pitch = _pitch_of(final_quat)
        final_err = float((target_pitch - final_pitch + np.pi) % (2 * np.pi) - np.pi)
        _record_drift()
        max_pos_drift_m = round(max_drift, 4)
        return ToolResult(
            data={
                "name": "rotate_pitch",
                "start_pitch": round(start_pitch, 4),
                "target_pitch": round(float(target_pitch), 4),
                "final_pitch": round(final_pitch, 4),
                "final_err": round(final_err, 4),
                "converged": abs(final_err) < tol,
                "max_pos_drift_m": max_pos_drift_m,
                "position_hold_ok": max_pos_drift_m <= pos_tol,
                "steps_used": len(traj),
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
            }
        )

    @tool
    def move_pose(
        self,
        xyz: Annotated[list[float], Field(min_length=3, max_length=3)],
        *,
        target_pitch: float | None = None,
        target_yaw: float | None = None,
        gripper: float = -1.0,
        step_clip: float = 0.02,
        pitch_step: float = 0.08,
        yaw_step: float = 0.08,
        tol: float = 0.012,
        ori_tol: float = 0.05,
        action_scale: float = 0.05,
        max_steps: int = 150,
    ) -> ToolResult:
        """Servo position AND orientation (pitch + yaw) SIMULTANEOUSLY. Unlike move_to (holds orientation) + rotate_pitch (holds xyz), this co-varies xyz and wrist tilt every env.step. Use to thread cabinet-front / low-shelf poses where a decoupled position servo drives the wrist into an IK singularity and stalls.

        Args:
            xyz: World-frame target [x, y, z] in meters
            target_pitch: Absolute pitch target, rad
            target_yaw: Absolute yaw target, rad
            gripper: Gripper command held during the move (default -1)
            step_clip: Per-step Δxyz cap, m (default 0.02)
            pitch_step: Per-step pitch clip, rad (default 0.08)
            yaw_step: Per-step yaw clip, rad (default 0.08)
            tol: Position tolerance, m (default 0.012)
            ori_tol: Orientation tolerance, rad (default 0.05)
            action_scale: OSC action scale (default 0.05)
            max_steps: Step budget (default 150)
        """
        from scipy.spatial.transform import Rotation as _R

        def _pitch_of(q):
            R = _R.from_quat([q[0], q[1], q[2], q[3]]).as_matrix()
            return float(np.arctan2(R[1, 2], -R[2, 2]))

        def _yaw_of(q):
            R = _R.from_quat([q[0], q[1], q[2], q[3]]).as_matrix()
            return float(np.arctan2(R[1, 0], R[0, 0]))

        target = np.asarray(_normalize_xyz(xyz), dtype=np.float32)
        traj = []
        step = 0
        for step in range(max_steps):
            cur = self._last_obs_eef_pos
            q = self.env.raw_obs()["robot0_eef_quat"]
            diff = target - cur
            dist = float(np.linalg.norm(diff))
            p_err = (
                0.0
                if target_pitch is None
                else float((target_pitch - _pitch_of(q) + np.pi) % (2 * np.pi) - np.pi)
            )
            y_err = (
                0.0
                if target_yaw is None
                else float((target_yaw - _yaw_of(q) + np.pi) % (2 * np.pi) - np.pi)
            )
            traj.append(
                {
                    "step": step,
                    "eef": [round(float(x), 4) for x in cur],
                    "dist": round(dist, 4),
                    "p_err": round(p_err, 3),
                }
            )
            if dist < tol and abs(p_err) < ori_tol and abs(y_err) < ori_tol:
                break
            action = np.zeros(7, dtype=np.float32)
            sd = np.clip(diff, -step_clip, step_clip)
            action[:3] = np.clip(sd / action_scale, -1.0, 1.0)
            action[3] = float(
                np.clip(np.clip(p_err, -pitch_step, pitch_step) / 0.10, -1.0, 1.0)
            )
            action[5] = float(
                np.clip(np.clip(y_err, -yaw_step, yaw_step) / 0.10, -1.0, 1.0)
            )
            action[6] = float(gripper)
            self._step_env(action)
            if self.env.terminated or self.env.truncated:
                break
        final = self._last_obs_eef_pos
        fq = self.env.raw_obs()["robot0_eef_quat"]
        return ToolResult(
            data={
                "name": "move_pose",
                "final_eef_pos": [round(float(x), 4) for x in final],
                "final_dist_m": round(float(np.linalg.norm(target - final)), 4),
                "final_pitch": round(_pitch_of(fq), 4),
                "steps_used": step + 1,
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
            }
        )

    @tool
    def release(self, *, max_steps: int = 20) -> ToolResult:
        """Open the gripper for up to max_steps env steps while holding EEF in place. Triggers libero termination if the matching On/In predicate is met.

        Args:
            max_steps: Step budget (default 20)
        """
        assert max_steps > 0, f"max_steps must be > 0, got {max_steps}"
        start_grip = self._last_obs_gripper
        peak_grip = start_grip
        for step in range(max_steps):
            action = np.zeros(7, dtype=np.float32)
            action[6] = -1.0  # open
            self._step_env(action)
            peak_grip = max(peak_grip, self._last_obs_gripper)
            if self.env.terminated or self.env.truncated:
                break
        return ToolResult(
            data={
                "name": "release",
                "steps_used": step + 1,
                "start_gripper_opening": round(start_grip, 4),
                "peak_gripper_opening": round(peak_grip, 4),
                "final_gripper_opening": round(self._last_obs_gripper, 4),
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
            }
        )

    @tool
    def set_gripper(self, *, gripper: float = -1.0, steps: int = 5) -> ToolResult:
        """Hold the current EEF pose and drive the gripper command for `steps` env steps. Use to firm up a grip mid-carry.

        Args:
            gripper: Gripper command: -1 open, +1 close (default -1)
            steps: Number of env steps (default 5)
        """
        g = float(gripper)
        n = int(steps)
        for _ in range(n):
            action = np.zeros(7, dtype=np.float32)
            action[6] = g
            self._step_env(action)
            if self.env.terminated or self.env.truncated:
                break
        return ToolResult(
            data={
                "name": "set_gripper",
                "gripper": g,
                "steps": n,
                "terminated": self.env.terminated,
                "truncated": self.env.truncated,
            }
        )

    # ---- introspection helpers (for LLM-in-the-loop) ----

    @tool(readonly=True, exclude=("state",))
    def segment(
        self,
        prompt: str = "",
        camera: Literal["agentview", "wrist"] = "agentview",
        step: Annotated[int, Field(json_schema_extra={"default": -1})] = -1,
        point: Annotated[list[int], Field(min_length=2, max_length=2)] | None = None,
        min_score: float = 0.2,
        *,
        state: EnvState,
    ) -> ToolResult:
        """SAM3 visual segmentation over an existing run artifact. It never renders a new camera view. Provide exactly one text prompt or single positive point. A successful top-ranked mask is projected through the matching world map to produce world_xyz.

        Args:
            prompt: Object/text prompt to segment.
            camera: Artifact camera to use (default agentview).
            step: Step to segment; -1 = latest.
            point: Optional single positive point as [row, col]. Mutually exclusive with prompt.
            min_score: Minimum accepted mask score (default 0.2).
        """
        images: list[bytes] = []
        try:
            record = state.get(step)
        except Exception as exc:
            return ToolResult(data={"error": f"state step not available: {exc}"})
        nn = record.step_idx

        camera = camera or "agentview"
        prompt = prompt.strip()
        has_prompt = bool(prompt)
        has_point = point is not None
        if has_prompt == has_point:
            return ToolResult(
                data={"error": "segment needs exactly one of prompt or point"}
            )
        try:
            image_name, world_name, artifact_pairs = _select_segment_artifacts(
                state, record, camera
            )
        except ValueError as e:
            return ToolResult(data={"error": str(e)})
        if image_name is None or world_name is None:
            return ToolResult(
                data={
                    "error": "complete segment artifacts not found",
                    "step": nn,
                    "camera": camera,
                    "checked_artifacts": [
                        name
                        for (image, world) in artifact_pairs
                        for name in (image, world)
                        if name
                    ],
                }
            )

        try:
            data = self._sam3_client.segment(
                state.load_bytes(image_name, step=nn),
                text_prompt=prompt if has_prompt else None,
                point=point,
                min_score=min_score,
            )
        except ValueError as e:
            return ToolResult(
                data={
                    "error": str(e),
                    "step": nn,
                    "camera": camera,
                    "image_artifact": image_name,
                }
            )
        except Exception as e:
            return ToolResult(
                data={
                    "error": f"segmentation service call failed: {e}",
                    "step": nn,
                    "camera": camera,
                    "image_artifact": image_name,
                    "fallback": "Use manual visual localization and back_project.",
                }
            )

        # Reserve an index before writing; failed saves leave gaps, never reuse.
        with self._segment_index_lock:
            segment_index = self._segment_index
            self._segment_index += 1
        segment_name = f"segment_{segment_index:02d}.json"
        overlay_name = f"segment_overlay_{segment_index:02d}.png"
        saved_overlay = None
        mask = data.mask
        if data.found and isinstance(mask, np.ndarray):
            try:
                world_map = state.load(world_name, step=nn)
            except Exception as exc:
                world_result = {
                    "world_xyz": None,
                    "world_error": f"world map artifact not available: {exc}",
                    "expected_world_artifact": world_name,
                }
            else:
                world_result = _mask_to_world(mask, world_map)
                world_result["world_artifact"] = world_name
            overlay = _make_segment_overlay(state.load(image_name, step=nn), mask)
            if overlay is not None and state.save(
                overlay_name,
                overlay,
                step=nn,
            ):
                saved_overlay = overlay_name
        else:
            world_result = {
                "world_xyz": None,
                "world_error": data.reason or "segmentation did not find a mask",
            }

        segment_blob = {
            "found": data.found,
            "mode": "text" if has_prompt else "point",
            "camera": camera,
            "source_step": nn,
            "segment_index": segment_index,
            "image_artifact": image_name,
            "min_score": min_score,
            "score": round(float(data.score), 3) if data.score is not None else None,
            "box": data.box,
            "mask_shape": list(data.mask_shape) if data.mask_shape else None,
        }
        if has_prompt:
            segment_blob["prompt"] = prompt
        else:
            segment_blob["point"] = point
        if not data.found:
            segment_blob["error"] = data.reason or "SAM3 found no mask"
        segment_blob.update(world_result)
        saved_segment = state.save(
            segment_name,
            segment_blob,
            step=nn,
        )

        result = {
            "found": data.found,
            "step": nn,
            "camera": camera,
            "image_artifact": image_name,
            "score": segment_blob["score"],
            "box": segment_blob["box"],
            "world_xyz": segment_blob["world_xyz"],
            "world_error": segment_blob.get("world_error"),
        }
        if saved_segment is None:
            result["error"] = f"failed to persist segment artifact {segment_name}"
            result["code"] = "segment_artifact_save_failed"
            result["attempted_segment_artifact"] = segment_name
            if "error" in segment_blob:
                result["segmentation_error"] = segment_blob["error"]
            result["fallback"] = "Use manual visual localization and back_project."
        else:
            result["segment_artifact"] = saved_segment
        if saved_segment is not None and "error" in segment_blob:
            result["error"] = segment_blob["error"]
            result["fallback"] = "Use manual visual localization and back_project."
        if saved_overlay is not None:
            result["overlay_artifact"] = saved_overlay
            images.append(state.load_bytes(saved_overlay, step=nn))
        return ToolResult(data=result, images=images)


def _is_primitive_action(name: object) -> bool:
    """Whether ``name`` is a state-advancing LIBERO primitive.

    A primitive is any non-read-only tool on :class:`LiberoPrimitives`;
    read-only tools and non-strings read as ``False``.
    """
    if not isinstance(name, str):
        return False
    method = getattr(LiberoPrimitives, name, None)
    return isinstance(method, Tool) and not method.readonly


def write_recipe_from_states(
    state: EnvState, recipe_tag: str, *, output_dir: Path | str
) -> str:
    """Find a command sequence that gets ``terminated=True``.

    Export non-error LIBERO primitive commands and successful segment calls.
    """
    records = state.records()
    last_reset = max(
        (
            record.step_idx
            for record in records
            if (
                (record.command or {}).get("action") == "reset"
                and not (isinstance(record.result, dict) and record.result.get("error"))
            )
        ),
        default=-1,
    )
    command_events = []
    for record in records:
        if record.step_idx < last_reset:
            continue
        command = record.command
        result = record.result
        if (
            command is not None
            and command.get("action") != "segment"
            and _is_primitive_action(command.get("action"))
            and not (isinstance(result, dict) and result.get("error"))
        ):
            command_events.append(((record.step_idx, -1), command))

        for name in sorted(record.artifacts):
            if not (name.startswith("segment_") and name.endswith(".json")):
                continue
            segment = state.load(name, step=record.step_idx)
            if segment.get("error"):
                continue
            if segment["mode"] == "text":
                segment_command = {
                    "action": "segment",
                    "prompt": segment["prompt"],
                    "camera": segment["camera"],
                }
            else:
                segment_command = {
                    "action": "segment",
                    "point": segment["point"],
                    "camera": segment["camera"],
                }
            event_order = (record.step_idx, int(segment["segment_index"]))
            command_events.append((event_order, segment_command))

    # Never publish a failed trajectory as a recipe. The environment trace is
    # authoritative; an agent's self-reported finish status is not.
    solved = any(
        record.terminated for record in records if record.step_idx > last_reset
    )
    if not solved:
        return ""
    command_events.sort(key=lambda event: event[0])
    recipe_name = f"{recipe_tag}_recipe.jsonl"
    recipe_path = Path(output_dir) / recipe_name
    recipe_path.parent.mkdir(parents=True, exist_ok=True)
    recipe_path.write_text(
        "".join(json.dumps(command) + "\n" for _, command in command_events)
    )
    return recipe_name


def _metric_depth(depth: Any, camera_meta: dict) -> np.ndarray:
    d = np.asarray(depth, dtype=np.float32)
    if d.ndim == 3:
        d = d[..., 0]
    near = camera_meta.get("depth_near")
    far = camera_meta.get("depth_far")
    if near is not None and far is not None:
        d = near / (1.0 - d * (1.0 - near / far))
    return d


def _world_from_depth(depth_metric: np.ndarray, camera_meta: dict) -> np.ndarray:
    k_matrix = np.array(camera_meta["intrinsic_K"], dtype=np.float64)
    extrinsic = np.array(camera_meta["extrinsic_cam2world"], dtype=np.float64)
    fx, fy = k_matrix[0, 0], k_matrix[1, 1]
    cx, cy = k_matrix[0, 2], k_matrix[1, 2]
    height, width = depth_metric.shape
    rr, cc = np.mgrid[0:height, 0:width]
    z = depth_metric.astype(np.float64)
    camera_points = np.stack(
        [(cc - cx) * z / fx, (rr - cy) * z / fy, z, np.ones_like(z)],
        axis=-1,
    )
    return (camera_points @ extrinsic.T)[..., :3]


def dump_state(
    primitives: LiberoPrimitives,
    env_state: EnvState,
    log: dict | None = None,
) -> StepRecord:
    """Save one Libero observation through its owned state record."""
    raw = primitives.env.raw_obs()
    state = {
        "robot0_eef_pos": [float(x) for x in raw["robot0_eef_pos"]],
        "robot0_eef_quat": [float(x) for x in raw["robot0_eef_quat"]],
        "robot0_gripper_qpos": [float(x) for x in raw["robot0_gripper_qpos"]],
        "object_names": sorted(
            k[:-4]
            for k in raw
            if k.endswith("_pos") and "robot0" not in k and "to_robot" not in k
        ),
    }
    log = log or {}
    with env_state.record_step(
        state=state,
        terminated=primitives.env.terminated,
        truncated=primitives.env.truncated,
        command=log.get("command"),
        result=log.get("result"),
        elapsed_s=log.get("elapsed_s"),
        extras={
            "task_language": primitives.env.get_task_language(),
        },
    ) as step_idx:
        _save_observation_artifacts(primitives, env_state, step_idx, raw)
    return env_state.get(step_idx)


def _save_observation_artifacts(
    primitives: LiberoPrimitives,
    env_state: EnvState,
    step_idx: int,
    raw: dict[str, Any],
) -> None:
    env_state.save(
        "agentview_policy.png",
        primitives._last_obs["main_images"],
        step=step_idx,
    )

    # --- camera calibration (static for agentview): fetch metadata as needed ---
    agentview_meta = (
        primitives.env.get_camera_meta(
            camera_name="agentview",
            height=256,
            width=256,
        )
        or {}
    )
    if agentview_meta:
        cam_meta_out = dict(agentview_meta)
        cam_meta_out["projection"] = (
            "Prefer the back_project(row, col, step=NN) MCP tool; it "
            "uses the 1024x1024 high-resolution world map by default. "
            "Pass resolution='low' only when row/col came from the "
            "256x256 calibration-frame image."
        )
        cam_meta_out["note"] = (
            "The agentview_depth.npz observation is aligned with agentview.png. "
            "agentview_policy.png uses the Pi0 orientation and must not supply "
            "pixels for back-projection."
        )
        env_state.save(
            "agentview_metadata.json",
            cam_meta_out,
            step=step_idx,
        )

    # --- per-step RGB in the depth/K frame (vertical-flip of the raw buffer) ---
    # Agentview pixels align with the matching depth and calibration. The policy
    # image uses Pi0 orientation and must not supply back-projection pixels.
    try:
        ci = raw.get("agentview_image")
        if ci is not None:
            ci = np.asarray(ci)
            if ci.dtype != np.uint8:
                ci = ci.astype(np.uint8)
            env_state.save(
                "agentview.png",
                ci[::-1],
                step=step_idx,
            )
    except Exception as e:
        logger.warning("image_cam dump failed: %s", e)

    # --- per-step metric depth (agentview), native orientation, in meters ---
    try:
        d = raw.get("agentview_depth")
        if d is not None:
            # Vertical flip to align with the camera matrices: robosuite's
            # camera_utils projection M = K_exp @ inv(extrinsic) expects the
            # depth map in this frame. VERIFIED 5/5: projecting each GT object
            # world pos via M lands on a pixel whose depth_flip[row,col] matches
            # the object's surface depth (plate Δ6mm, cookies Δ14mm). So
            # Pixels in agentview.png align with agentview_depth.npz and the
            # per-step agentview metadata saved with the record artifacts.
            d = _metric_depth(d, agentview_meta)[::-1]
            env_state.save(
                "agentview_depth.npz",
                d.astype(np.float32),
                step=step_idx,
            )
            world = _world_from_depth(d, agentview_meta).astype(np.float32)
            env_state.save(
                "agentview_world.npz",
                world,
                step=step_idx,
            )
    except Exception as e:
        logger.warning("depth dump failed: %s", e)

    # --- per-step wrist camera (robot0_eye_in_hand), calibration frame ---
    try:
        wimg = raw.get("robot0_eye_in_hand_image")
        if wimg is None:
            logger.warning("wrist image missing from raw_obs")
        else:
            wimg = np.asarray(wimg)
            if wimg.dtype != np.uint8:
                wimg = wimg.astype(np.uint8)
            env_state.save(
                "wrist.png",
                wimg[::-1],
                step=step_idx,
            )
    except Exception as e:
        logger.warning("wrist image dump failed: %s", e)

    try:
        wdpt = raw.get("robot0_eye_in_hand_depth")
        if wdpt is None:
            logger.warning("wrist depth missing from raw_obs")
        else:
            wdpt_arr = np.asarray(wdpt, dtype=np.float32)
            height, width = wdpt_arr.shape[:2]
            wmeta = primitives.env.get_camera_meta(
                camera_name="robot0_eye_in_hand",
                height=int(height),
                width=int(width),
            )
            if wmeta is None:
                logger.warning("wrist camera meta missing; skipping wrist depth/world")
            else:
                wdpt_metric = _metric_depth(wdpt_arr, wmeta)[::-1]
                env_state.save(
                    "wrist_depth.npz",
                    wdpt_metric.astype(np.float32),
                    step=step_idx,
                )
                world_w = _world_from_depth(wdpt_metric, wmeta).astype(np.float32)
                env_state.save(
                    "wrist_world.npz",
                    world_w,
                    step=step_idx,
                )

                wmeta_out = dict(wmeta)
                wmeta_out["note"] = (
                    "MOVING camera: extrinsic_cam2world is for THIS step "
                    "only. The matching wrist world-map observation gives world "
                    "(x,y,z) for that pixel in the same world frame as the "
                    "agentview world-map artifact."
                )
                env_state.save(
                    "wrist_metadata.json",
                    wmeta_out,
                    step=step_idx,
                )
    except Exception as e:
        logger.warning("wrist depth/world dump failed: %s", e)

    try:
        rgb_hi, depth_hi = primitives.env.render_camera(
            camera_name="agentview",
            height=1024,
            width=1024,
            depth=True,
        )
        meta_hi = primitives.env.get_camera_meta("agentview", 1024, 1024)
        if meta_hi is None:
            raise RuntimeError("agentview camera metadata missing")
        env_state.save(
            "agentview_high.png",
            np.asarray(rgb_hi)[::-1],
            step=step_idx,
        )
        world_hi = _world_from_depth(
            _metric_depth(depth_hi, meta_hi)[::-1],
            meta_hi,
        ).astype(np.float16)
        env_state.save(
            "agentview_world_high.npz",
            world_hi,
            step=step_idx,
        )
    except Exception as e:
        logger.warning("agentview high-res dump failed: %s", e)

    try:
        rgb_wrist_hi, depth_wrist_hi = primitives.env.render_camera(
            camera_name="robot0_eye_in_hand",
            height=1024,
            width=1024,
            depth=True,
        )
        meta_wrist_hi = primitives.env.get_camera_meta("robot0_eye_in_hand", 1024, 1024)
        if meta_wrist_hi is None:
            raise RuntimeError("robot0_eye_in_hand camera metadata missing")
        env_state.save(
            "wrist_high.png",
            np.asarray(rgb_wrist_hi)[::-1],
            step=step_idx,
        )
        world_wrist_hi = _world_from_depth(
            _metric_depth(depth_wrist_hi, meta_wrist_hi)[::-1],
            meta_wrist_hi,
        ).astype(np.float16)
        env_state.save(
            "wrist_world_high.npz",
            world_wrist_hi,
            step=step_idx,
        )
    except Exception as e:
        logger.warning("wrist high-res dump failed: %s", e)


# ---------------------------------------------------------------------------
# Tool schema declarations (Anthropic-shaped canonical schema)
# ---------------------------------------------------------------------------


@tool(readonly=True, exclude=("state",))
def view_env_state(
    step: Annotated[int, Field(json_schema_extra={"default": -1})] = -1,
    *,
    state: EnvState,
) -> ToolResult:
    """Read one recorded state and its observation artifacts. Step -1 selects the latest entry. Embeds policy, agentview, and wrist images when available. Use the calibration-frame images for pixel back-projection; JSON state alone is not enough. Use agentview for global tabletop layout and object locations; use wrist for close-range details near the gripper, occlusions, and container/cabinet interiors.

    Args:
        step: Step number; 0 = initial, -1 = latest.
    """
    images: list[bytes] = []
    try:
        record = state.get(step)
    except Exception as exc:
        return ToolResult(data={"error": f"state step not available: {exc}"})

    nn = record.step_idx
    extras = record.extras
    out: dict = {
        "step": nn,
        "terminated": record.terminated,
        "truncated": record.truncated,
        "state": record.state,
        "artifacts": sorted(record.artifacts),
    }
    out["task_language"] = extras.get("task_language")
    out["log"] = {
        "command": record.command,
        "result": record.result,
        "elapsed_s": record.elapsed_s,
    }
    for names in (
        ("agentview_policy.png",),
        ("agentview_high.png", "agentview.png"),
        ("wrist_high.png", "wrist.png"),
    ):
        name = next((name for name in names if name in record.artifacts), None)
        if name:
            try:
                images.append(state.load_bytes(name, step=nn))
            except FileNotFoundError:
                pass
    return ToolResult(data=out, images=images)


def _select_segment_artifacts(
    state: EnvState,
    record: StepRecord,
    camera: str,
) -> tuple[str | None, str | None, list[tuple[str | None, str | None]]]:
    if camera not in ("agentview", "wrist"):
        raise ValueError(f"unknown segment camera: {camera}")
    pairs = [
        (f"{camera}_high.png", f"{camera}_world_high.npz"),
        (f"{camera}.png", f"{camera}_world.npz"),
    ]
    for image_name, world_name in pairs:
        if (
            image_name in record.artifacts
            and world_name in record.artifacts
            and state.exists(image_name, step=record.step_idx)
            and state.exists(world_name, step=record.step_idx)
        ):
            return image_name, world_name, pairs
    return None, None, pairs


def _mask_to_world(
    mask: np.ndarray, world_map: np.ndarray, min_valid: int = 10
) -> dict:
    if world_map.ndim != 3 or world_map.shape[2] < 3:
        return {
            "world_xyz": None,
            "world_error": f"invalid world map shape: {tuple(world_map.shape)}",
            "n_pixels": int(mask.sum()),
            "n_valid": 0,
            "mask_resized_to_world_shape": False,
        }

    if mask.shape != world_map.shape[:2]:
        return {
            "world_xyz": None,
            "world_error": (
                f"mask/world shape mismatch: mask={tuple(mask.shape)}, "
                f"world={tuple(world_map.shape[:2])}"
            ),
            "n_pixels": int(mask.sum()),
            "n_valid": 0,
            "mask_resized_to_world_shape": False,
        }

    ys, xs = np.where(mask)
    if ys.size == 0:
        return {"world_xyz": None, "world_error": "empty mask"}

    pts = world_map[ys, xs].astype(np.float64)
    valid = np.isfinite(pts).all(axis=1) & (np.abs(pts).sum(axis=1) > 1e-6)
    pts = pts[valid]
    result = {
        "centroid_pixel": [
            int(round(float(np.median(xs)))),
            int(round(float(np.median(ys)))),
        ],
        "n_pixels": int(mask.sum()),
        "n_valid": int(pts.shape[0]),
        "mask_resized_to_world_shape": False,
    }
    if pts.shape[0] < min_valid:
        result.update(
            {
                "world_xyz": None,
                "world_error": f"too few valid depth pixels ({int(pts.shape[0])})",
            }
        )
        return result

    result["world_xyz"] = [
        round(float(np.median(pts[:, 0])), 4),
        round(float(np.median(pts[:, 1])), 4),
        round(float(np.median(pts[:, 2])), 4),
    ]
    return result


def _make_segment_overlay(
    image: np.ndarray,
    mask: np.ndarray,
) -> np.ndarray | None:
    if image.ndim != 3 or image.shape[:2] != mask.shape:
        return None
    overlay = image.copy()
    red = np.zeros_like(overlay)
    red[..., 0] = 255
    overlay[mask] = (
        0.55 * overlay[mask].astype(np.float32) + 0.45 * red[mask].astype(np.float32)
    ).astype(np.uint8)
    return overlay


@tool(readonly=True, exclude=("state",))
def view_camera_meta(
    camera: Literal["agentview", "wrist"] = "agentview",
    step: Annotated[int, Field(json_schema_extra={"default": -1})] = -1,
    *,
    state: EnvState,
) -> ToolResult:
    """Read per-step camera calibration metadata from recorded artifacts.

    Args:
        camera: Camera metadata to read (default agentview).
        step: Metadata step to use; -1 = latest.
    """
    if camera not in ("agentview", "wrist"):
        return ToolResult(
            data={"error": f"bad camera '{camera}' (use 'agentview' or 'wrist')"}
        )

    try:
        record = state.get(step)
        metadata_name = f"{camera}_metadata.json"
        if metadata_name not in record.artifacts:
            raise FileNotFoundError(metadata_name)
        meta = state.load(metadata_name, step=record.step_idx)
    except Exception as e:
        return ToolResult(data={"error": f"{camera} camera metadata not found: {e}"})

    if camera == "agentview":
        return ToolResult(data={"camera": "agentview", "camera_meta": meta})
    return ToolResult(
        data={"camera": "wrist", "step": record.step_idx, "camera_meta": meta}
    )


@tool(readonly=True, exclude=("state",))
def back_project(
    row: int | None = None,
    col: int | None = None,
    step: Annotated[int, Field(json_schema_extra={"default": -1})] = -1,
    camera: Literal["agentview", "wrist"] = "agentview",
    resolution: Literal["high", "low"] = "high",
    row_range: list[int] | None = None,
    col_range: list[int] | None = None,
    z_min: float | None = None,
    z_max: float | None = None,
    *,
    state: EnvState,
) -> ToolResult:
    """Back-project a pixel (row, col) to a world XYZ point using the selected camera's precomputed world map. Row 0 = top of image, col 0 = left. Returns world_xyz in meters.

    USE THIS to find where an object is in the world — look at the embedded high-resolution image returned by view_env_state to pick a pixel on the target object, then call back_project. The default resolution is high (1024x1024). Pass resolution='low' only for pixels from the embedded/standard 256 image. The pixel coordinates must come from the same camera and resolution requested here. Use camera='agentview' for global tabletop layout and object locations; use camera='wrist' for close-range details near the gripper, occlusions, and container/cabinet interiors. Sample several pixels on the object and median their xy for robustness.

    REGION MODE: pass row_range=[r0,r1] and col_range=[c0,c1] instead of row/col to get the midpoint of world xy over that pixel window, with an optional world-z band (z_min, z_max). Use it for the center of a container cavity or flat region, where a single-pixel or mask-median estimate is biased toward an edge/rim.

    Args:
        row: Pixel row (0=top) in the selected resolution image.
        col: Pixel column (0=left) in the selected resolution image.
        step: Depth/world-map step; 0 = initial, -1 = latest.
        camera: Camera to back-project from (default agentview).
        resolution: Coordinate system for row/col (default high). Use low only when row/col came from the embedded/standard 256 image.
        row_range: Region mode: [r0, r1] pixel row window. Requires col_range.
        col_range: Region mode: [c0, c1] pixel col window. Requires row_range.
        z_min: Region mode: keep only pixels with world z >= z_min.
        z_max: Region mode: keep only pixels with world z <= z_max.
    """
    if camera not in ("agentview", "wrist"):
        return ToolResult(
            data={"error": f"bad camera '{camera}' (use 'agentview' or 'wrist')"}
        )
    if resolution not in ("high", "low"):
        return ToolResult(
            data={"error": f"bad resolution '{resolution}' (use 'high' or 'low')"}
        )

    region_mode = row_range is not None or col_range is not None
    if not region_mode and (row is None or col is None):
        return ToolResult(
            data={
                "error": (
                    "provide either (row, col) for a single pixel, or "
                    "row_range=[r0,r1] and col_range=[c0,c1] for a region center"
                )
            }
        )

    try:
        record = state.get(step)
    except Exception as e:
        return ToolResult(data={"error": f"state step not available: {e}"})
    nn = record.step_idx

    hi_artifact = f"{camera}_world_high.npz"
    low_artifact = f"{camera}_world.npz"
    source_artifact = hi_artifact if resolution == "high" else low_artifact
    if source_artifact not in record.artifacts:
        return ToolResult(
            data={
                "error": (
                    f"{camera} {resolution}-resolution world map not recorded for step {nn}"
                )
            }
        )

    try:
        world_map = state.load(str(source_artifact), step=nn)
    except Exception as e:
        return ToolResult(
            data={
                "error": (
                    f"{camera} {resolution}-resolution artifact not found "
                    f"for step {nn}: {e}"
                )
            }
        )

    height, width = world_map.shape[:2]

    if region_mode:
        if row_range is None or col_range is None:
            return ToolResult(
                data={
                    "error": (
                        "region mode needs BOTH row_range=[r0,r1] and col_range=[c0,c1]"
                    )
                }
            )
        try:
            r0, r1 = int(row_range[0]), int(row_range[1])
            c0, c1 = int(col_range[0]), int(col_range[1])
        except Exception:
            return ToolResult(
                data={"error": "row_range/col_range must each be [min, max] integers"}
            )
        r0, r1 = sorted((max(0, r0), min(height, r1)))
        c0, c1 = sorted((max(0, c0), min(width, c1)))
        if r1 <= r0 or c1 <= c0:
            return ToolResult(
                data={
                    "error": (
                        f"empty region after clamping to image {height}x{width}: "
                        f"rows [{r0},{r1}] cols [{c0},{c1}]"
                    )
                }
            )
        window = (
            world_map[r0:r1, c0:c1].reshape(-1, world_map.shape[2]).astype(np.float64)
        )
        finite = np.isfinite(window).all(axis=1) & (
            np.abs(window[:, :3]).sum(axis=1) > 1e-6
        )
        pts = window[finite]
        n_total = int(pts.shape[0])
        if z_min is not None:
            pts = pts[pts[:, 2] >= float(z_min)]
        if z_max is not None:
            pts = pts[pts[:, 2] <= float(z_max)]
        if pts.shape[0] < 8:
            return ToolResult(
                data={
                    "error": (
                        f"too few valid pixels in region after z-filter "
                        f"({int(pts.shape[0])}); widen the window or the z band"
                    ),
                    "n_valid_before_zfilter": n_total,
                }
            )
        xs, ys, zs = pts[:, 0], pts[:, 1], pts[:, 2]
        center = [
            round(float((xs.min() + xs.max()) / 2.0), 4),
            round(float((ys.min() + ys.max()) / 2.0), 4),
            round(float(np.median(zs)), 4),
        ]
        return ToolResult(
            data={
                "camera": camera,
                "resolution": resolution,
                "mode": "region",
                "row_range": [r0, r1],
                "col_range": [c0, c1],
                "z_band": [z_min, z_max],
                "center_xyz": center,
                "median_xyz": [
                    round(float(np.median(xs)), 4),
                    round(float(np.median(ys)), 4),
                    round(float(np.median(zs)), 4),
                ],
                "n_valid": int(pts.shape[0]),
                "step": nn,
                "image_size": [height, width],
                "source_artifact": source_artifact,
            }
        )

    if row < 0 or row >= height or col < 0 or col >= width:
        return ToolResult(
            data={
                "error": (
                    f"pixel ({row},{col}) out of bounds; {camera} image is {height}x{width}"
                )
            }
        )

    depth_m = None
    if source_artifact == low_artifact:
        try:
            depth_artifact = f"{camera}_depth.npz"
            if depth_artifact not in record.artifacts:
                raise FileNotFoundError(depth_artifact)
            depth = state.load(depth_artifact, step=nn)
            if depth.ndim == 3:
                depth = depth[..., 0]
        except Exception as e:
            return ToolResult(
                data={"error": f"{camera} depth not found for step {nn}: {e}"}
            )
        depth_m = float(depth[row, col])
        if not np.isfinite(depth_m) or depth_m <= 0 or depth_m > 10:
            return ToolResult(
                data={
                    "error": (
                        f"invalid {camera} depth {depth_m:.3f}m at pixel "
                        f"({row},{col}); pick a different pixel"
                    )
                }
            )
    world_xyz_raw = world_map[row, col]
    if (
        not np.isfinite(world_xyz_raw).all()
        or float(np.abs(world_xyz_raw[:3]).sum()) <= 1e-6
    ):
        return ToolResult(
            data={"error": f"invalid {camera} world xyz at pixel ({row},{col})"}
        )
    world_xyz = [round(float(v), 4) for v in world_xyz_raw[:3]]

    out = {
        "camera": camera,
        "resolution": resolution,
        "pixel": [row, col],
        "world_xyz": world_xyz,
        "step": nn,
        "image_size": [height, width],
        "source_artifact": source_artifact,
    }
    if depth_m is not None:
        out["depth_m"] = round(depth_m, 4)
    return ToolResult(data=out)
