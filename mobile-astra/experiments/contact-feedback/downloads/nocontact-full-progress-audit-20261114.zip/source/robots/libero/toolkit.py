# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LIBERO toolkit: common tools + LIBERO primitives.

Inherits the common file/IO tools from :class:`Toolkit` and registers the
LIBERO primitives (``move_to``, ``pi0_pick``, ``release``, ...) on top.
"""

from __future__ import annotations

from collections.abc import Callable
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any

from robots.libero import tools as libero_tools
from rpent.dashboard.events import DashboardEventSink
from rpent.session import EnvState
from rpent.tools import ToolResult, iter_tools
from rpent.tools.base import tool
from rpent.tools.direct_action import direct_action_tool
from rpent.tools.toolkit import Toolkit
from rpent.utils.logging import get_logger, get_output_dir

if TYPE_CHECKING:
    from rpent.memory.manager import MemoryManager

logger = get_logger("libero_toolkit")


class LiberoToolkit(Toolkit):
    """Toolkit for the LIBERO robot."""

    def __init__(
        self,
        *,
        runtime_kwargs: dict[str, Any],
        dashboard_events: DashboardEventSink,
        memory: MemoryManager,
        enable_direct_action: bool = False,
        mode: str = "evaluation",
        attempts_per_session: int = 0,
        state_output_dir: Path | str | None = None,
    ) -> None:
        if mode not in {"evaluation", "exploration"}:
            raise ValueError(f"unsupported LIBERO toolkit mode: {mode!r}")
        self._state_output_dir = Path(state_output_dir or get_output_dir())
        state = EnvState(self._state_output_dir)
        super().__init__(
            dashboard_events=dashboard_events,
            state=state,
            memory=memory,
        )
        self._mode = mode
        self._solved: bool = False
        self._attempt: int = 1
        # Bound the resettable attempts owned by this planner session.
        self._attempts_per_session: int = max(0, int(attempts_per_session))
        self._session_attempt: int = 1
        self.init_primitives(runtime_kwargs=runtime_kwargs)
        self._register_libero_tools()
        if enable_direct_action:
            self.add_tool(
                direct_action_tool(
                    self._primitives.env.action_specs,
                    partial(
                        self._execute_primitive,
                        "execute_action",
                        self._primitives.execute_action,
                    ),
                )
            )

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------
    def _register_libero_tools(self) -> None:
        for definition in iter_tools(libero_tools):
            self.add_tool(
                definition.with_handler(partial(definition, state=self._state))
            )
        for definition in iter_tools(self._primitives):
            if definition.name == "segment":
                handler = partial(definition, state=self._state)
            else:
                handler = partial(self._execute_primitive, definition.name, definition)
            self.add_tool(definition.with_handler(handler))
        if self._mode == "exploration":
            self.add_tool(self._reset_episode)
            finish = self._tools["finish"]
            self.add_tool(
                finish.with_handler(partial(self._guarded_finish, finish)), replace=True
            )

    def _execute_primitive(
        self, name: str, handler: Callable[..., ToolResult], **kwargs: Any
    ) -> ToolResult:
        self._primitives.begin_primitive(name)
        try:
            return handler(**kwargs)
        finally:
            self._primitives.end_primitive()

    def _guarded_finish(self, inner: Any, **kwargs: Any) -> ToolResult:
        """Refuse to end an unsolved session while attempts remain."""
        budget = self._attempts_per_session
        if budget and not self.solved() and self._session_attempt < budget:
            remaining = budget - self._session_attempt
            return ToolResult(
                data={
                    "error": "finish refused",
                    "reason": f"This session has {remaining} of its {budget} attempts left and the task is not solved. Archive this attempt, call `reset`, and try another approach.",
                }
            )
        return inner(**kwargs)

    @tool(name="reset")
    def _reset_episode(self, reason: str) -> ToolResult:
        """EXPLORE MODE ONLY. Abandon the current episode and restore the same initial scene. Archive the failed attempt first and state which strategy lever will change in the next attempt.

        Args:
            reason: Why this episode is unrecoverable and what will change.
        """
        budget = self._attempts_per_session
        if budget and self._session_attempt >= budget:
            return ToolResult(
                data={
                    "error": "reset refused",
                    "reason": f"This session's attempt budget is spent ({budget} attempts). Archive the attempt, update the handoff notes, and call `finish` so the next session can continue.",
                }
            )
        self._attempt += 1
        self._session_attempt += 1
        result = self._primitives.reset_episode(reason=reason)
        result["attempt"] = self._attempt
        result["notice"] = (
            f"Episode restarted; this is attempt {self._attempt}. The original "
            "layout was restored. Re-run perception before acting."
        )
        return ToolResult(data=result)

    def get_env_state(
        self,
        *,
        command: dict[str, Any],
        result: dict[str, Any],
        elapsed_s: float,
    ) -> ToolResult:
        frame_start = self._action_frame_cursor
        self._action_frame_cursor = self._primitives.recorded_frame_count()
        record = libero_tools.dump_state(
            self._primitives,
            self._state,
            log={"command": command, "result": result, "elapsed_s": elapsed_s},
        )
        self._solved |= record.terminated
        if self._dashboard_events.enabled:
            try:
                frames = self._primitives.frame_slice(frame_start)
                if frames:
                    candidate = f"action_{command['action']}.mp4"
                    self._state.save(
                        candidate,
                        frames,
                        step=record.step_idx,
                        fps=20,
                    )
            except Exception as e:
                logger.warning(
                    "failed to save action clip for step %s: %s",
                    record.step_idx,
                    e,
                )
        out = libero_tools.view_env_state(record.step_idx, state=self._state)
        out.data["agent_elapsed_s"] = elapsed_s
        if result.get("interrupted"):
            out.data.update(result)
        return out

    @property
    def primitives(self) -> "libero_tools.LiberoPrimitives":
        """Return the action primitives this toolkit drives."""
        return self._primitives

    def init_primitives(
        self,
        *,
        runtime_kwargs: dict[str, Any],
    ) -> None:
        """Wipe stale run artifacts, build the LiberoPrimitives, dump step 0."""
        self._state.reset()

        primitives = libero_tools.LiberoPrimitives(
            check_cancelled=self.raise_if_cancelled,
            **runtime_kwargs,
        )
        primitives.reset()
        primitives.start_recording()
        self._action_frame_cursor = primitives.recorded_frame_count()
        record = libero_tools.dump_state(primitives, self._state, log=None)
        self._primitives = primitives
        self._publish_step(record)

    def close(self) -> None:
        """Finalize collected data and save the episode video independently."""
        super().close()
        try:
            episode = self._primitives.finalize_flywheel()
            if episode is not None:
                logger.info("flywheel episode finalized: %s", episode)
        except Exception as e:
            logger.warning("failed to finalize flywheel episode: %s", e)

        try:
            frames = self._primitives.stop_recording()
            if frames:
                self._state.save("episode.mp4", frames, step=None, fps=20)
        except Exception as e:
            # The runner is in the cleanup path; never let a video save
            # abort it.
            logger.warning(f"failed to save episode video: {e}")

    def solved(self) -> bool:
        """Return whether this run has completed the task."""
        return self._solved

    def write_recipe(self, recipe_tag: str) -> str:
        """Write the LIBERO recipe JSONL from the dumped state trace."""
        return libero_tools.write_recipe_from_states(
            self._state, recipe_tag, output_dir=get_output_dir()
        )
