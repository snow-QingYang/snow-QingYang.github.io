# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step-based Flash plans shared by single and dual Franka."""

from typing import Any, Callable


def replay_card(toolkit: Any, cell_tag: str, note: Callable[[str], None]) -> dict:
    """Dispatch the robot-owned Flash hook with lazy runtime imports."""
    from robots.franka.flash.replay import replay_card as run

    return run(toolkit, cell_tag, note)
