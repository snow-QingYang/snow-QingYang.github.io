# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Franka visual replay through the existing RobotSpec.run_flash hook."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy.spatial.transform import Rotation

from robots.franka.flash.common import (
    VLA_ACTIONS,
    checked_result,
    fingerprint,
    tcp_pose,
    validate_card,
    vector,
)


def ask_human(question: str, choices: tuple[str, ...]) -> str:
    """Wait for an explicit operator answer; EOF never grants permission."""
    if not sys.stdin.isatty():
        raise RuntimeError("Franka Flash plans require an operator terminal")
    while True:
        answer = input(f"{question} [{' / '.join(choices)}]: ").strip().lower()
        if answer in choices:
            return answer


def add_cli_args(parser: argparse.ArgumentParser) -> None:
    """Add Franka Flash replay options."""
    parser.add_argument("--flash-plan", help="Generated Franka Flash JSON")
    parser.add_argument("--molmo-endpoint", help="Live Molmo grounding endpoint")
    parser.add_argument(
        "--grounding-agent-model",
        help="Optional fallback: codex:model or provider:model",
    )
    parser.add_argument(
        "--grounding-agent-base-url", help="Fallback model endpoint override"
    )


def prepare(args: argparse.Namespace, robot: str) -> dict[str, Any] | None:
    """Validate the selected plan before connecting to hardware."""
    if getattr(args, "planner", None) != "flash":
        return None
    if (
        getattr(args, "dashboard", False)
        or getattr(args, "interactive", False)
        or getattr(args, "explore", False)
    ):
        raise ValueError(
            "Franka Flash confirmation uses its own terminal; omit --dashboard/--interactive/--explore"
        )
    if not getattr(args, "flash_plan", None):
        raise ValueError("Franka flash requires --flash-plan")
    card = validate_card(json.loads(Path(args.flash_plan).read_text()))
    if not getattr(args, "molmo_endpoint", None):
        raise ValueError("visual flash requires --molmo-endpoint")
    if card["robot"] != robot or card["task"] != f"{robot}_t{args.task_id}":
        raise ValueError("card robot/task does not match requested robot/task")
    if card["requirements"] != fingerprint():
        raise ValueError(
            "card robot configuration or calibration changed; regenerate/review the card"
        )
    return {
        "grounding_agent_model": getattr(args, "grounding_agent_model", None),
        "grounding_agent_base_url": getattr(args, "grounding_agent_base_url", None),
        "card": card,
        "endpoint": args.molmo_endpoint,
    }


def authorize_runtime(args: argparse.Namespace) -> None:
    """Called before creating an EnvClient, whose constructor resets hardware."""
    if getattr(args, "planner", None) == "flash":
        if getattr(args, "dashboard", False) or getattr(args, "interactive", False):
            raise ValueError(
                "Franka Flash plans require the dedicated operator terminal"
            )
        options = getattr(args, "_flash_options", None)
        if options and any(e["action"] in VLA_ACTIONS for e in options["card"]["plan"]):
            if options["card"]["robot"] == "franka" and not args.vla_endpoint:
                raise ValueError("single-Franka VLA Flash plan requires --vla-endpoint")
        result = ask_human(
            "Restore the scene and clear the workspace. Allow driver initialization/reset?",
            ("ready", "abort"),
        )
        if result != "ready":
            raise RuntimeError("operator aborted before environment initialization")


def motion_arguments(
    entry: dict,
    *,
    robot: str,
    state: Any,
    molmo: Any,
    workspace: dict,
    toolkit: Any = None,
    grounding_agent: Any = None,
    note: Callable[[str], None] = lambda _: None,
) -> dict:
    """Resolve a recorded motion against the current calibrated observation."""
    args = dict(entry["arguments"])
    action = entry["action"]
    if action not in {"move_delta", "rotate_delta"}:
        return args
    pose = tcp_pose(state.get().state, robot, args.get("arm"))
    if action == "move_delta":
        from robots.franka.flash.common import localize
        from robots.franka.flash.grounding import localize_with_fallback

        if toolkit is None:
            point = localize(state, robot, entry["anchor"], molmo, arm=args.get("arm"))
        else:
            point = localize_with_fallback(
                toolkit,
                robot,
                entry["anchor"],
                molmo,
                arm=args.get("arm"),
                agent=grounding_agent,
                note=note,
            )
            pose = tcp_pose(state.get().state, robot, args.get("arm"))
        target = point + vector(entry["offset_xyz"])
        lower, upper = workspace["ee_pose_limit_min"], workspace["ee_pose_limit_max"]
        if robot == "dual_franka":
            index = 0 if args["arm"] == "left" else 1
            lower, upper = lower[index], upper[index]
        workspace_target = target
        if robot == "dual_franka" and args["arm"] == "left":
            from robots.dual_franka.perception import (
                transform_point_between_base_frames,
            )

            workspace_target = transform_point_between_base_frames(
                target, source="right_base", target="left_base"
            )
        if np.any(workspace_target < vector(lower[:3])) or np.any(
            workspace_target > vector(upper[:3])
        ):
            raise ValueError("grounded target is outside the configured arm workspace")
        delta = target - pose[:3]
        if np.linalg.norm(delta) > 0.20:
            raise ValueError(
                "grounded translation exceeds 0.20m; use intermediate recorded steps"
            )
        args["delta_xyz"] = delta.tolist()
    else:
        current = Rotation.from_quat(pose[3:])
        if entry["rotation_mode"] == "relative":
            reference = Rotation.from_quat(entry["reference_quaternion"])
            if (current * reference.inv()).magnitude() > 0.15:
                raise ValueError(
                    "relative rotation starting pose differs by more than 0.15rad"
                )
        else:
            target = Rotation.from_quat(entry["target_quaternion"])
            args["delta_rpy"] = (target * current.inv()).as_euler("xyz").tolist()
        if Rotation.from_euler("xyz", vector(args["delta_rpy"])).magnitude() > 0.35:
            raise ValueError(
                "rotation exceeds 0.35rad; use intermediate recorded steps"
            )
    return args


def replay(
    toolkit: Any,
    card: dict,
    molmo: Any,
    workspace: dict,
    *,
    human: Callable = ask_human,
    note: Callable[[str], None] = lambda _: None,
    grounding_agent: Any = None,
) -> dict:
    """Replay validated primitives and record the operator outcome."""
    validate_card(card)
    events = []
    outcome = {
        "card": card["task"],
        "done": False,
        "plan": 0,
        "anchors": 0,
        "events": events,
        "human_verdict": None,
    }
    toolkit._flash_solved = False
    if any(e["action"] in VLA_ACTIONS for e in card["plan"]):
        primitives = getattr(toolkit, "_primitives", None)
        if primitives is not None and primitives.model is None:
            raise ValueError("Flash plan requires a connected VLA model")
    try:
        decision = human(
            "Environment initialized. Clear the workspace and start card execution?",
            ("start", "abort"),
        )
        events.append(
            {
                "kind": "start",
                "answer": decision,
                "at": datetime.now(timezone.utc).isoformat(),
            }
        )
        if decision != "start":
            outcome["status"] = "aborted"
            return outcome
        for entry in card["plan"]:
            toolkit.raise_if_cancelled()
            # Refresh observations at each boundary, including after operator wait.
            toolkit.refresh_flash_state()
            args = motion_arguments(
                entry,
                robot=card["robot"],
                state=toolkit.state,
                molmo=molmo,
                workspace=workspace,
                toolkit=toolkit,
                grounding_agent=grounding_agent,
                note=note,
            )
            note(f"source step {entry['source_step']}: {entry['action']} {args}")
            event = {
                "source_step": entry["source_step"],
                "before_step": toolkit.state.latest_step,
                "action": entry["action"],
                "arguments": args,
            }
            events.append(event)
            result = toolkit.execute_tool(entry["action"], args).to_dict()
            event["replay_step"] = toolkit.state.latest_step
            # Franka's tool output is a rendered state; inspect the raw result too.
            checked_result(result)
            checked_result(toolkit.state.latest_record().result)
            outcome["plan"] += 1
            outcome["anchors"] += int(entry["action"] == "move_delta")
        verdict = human(
            "Card actions finished. Did the physical task succeed?",
            ("success", "failure"),
        )
        events.append(
            {
                "kind": "outcome",
                "answer": verdict,
                "at": datetime.now(timezone.utc).isoformat(),
            }
        )
        outcome.update(human_verdict=verdict, done=verdict == "success", status=verdict)
        toolkit._flash_solved = outcome["done"]
        return outcome
    except BaseException as exc:
        outcome.update(status="failure", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        toolkit.state.save("flash_outcome.json", outcome, step=None)
        toolkit.state.save(
            "flash_recipe.jsonl",
            [
                {"action": event["action"], **event["arguments"]}
                for event in events
                if "action" in event
            ],
            step=None,
        )


def replay_card(toolkit: Any, cell_tag: str, note: Callable[[str], None]) -> dict:
    """Run the robot-owned Flash hook and close its Molmo connection."""
    from robots.franka.runtime_config import get_robot_config_path, load_mapping
    from rpent.robots.components.molmo_client import MolmoClient
    from rpent.utils.rpc import make_rpc_client

    options = toolkit.flash_options
    if not options or options["card"]["task"] != cell_tag:
        raise ValueError("missing or mismatched Flash plan")
    if options["card"]["requirements"] != fingerprint():
        raise ValueError("configuration changed after card preparation")
    from rpent.robots.components.grounding_agent import GroundingAgent

    agent = (
        GroundingAgent(
            options["grounding_agent_model"], options.get("grounding_agent_base_url")
        )
        if options.get("grounding_agent_model")
        else None
    )
    rpc = make_rpc_client(options["endpoint"])
    try:
        return replay(
            toolkit,
            options["card"],
            MolmoClient(rpc),
            load_mapping(get_robot_config_path())["workspace"],
            note=note,
            grounding_agent=agent,
        )
    finally:
        if rpc:
            rpc.close()
