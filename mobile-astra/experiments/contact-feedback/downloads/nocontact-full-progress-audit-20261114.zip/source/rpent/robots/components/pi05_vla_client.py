# Copyright 2026 The RPent Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Thin client wrapping the Pi0.5 VLA RPC server.

The server lifecycle is the caller's responsibility: bring up
``rpent.robots.components.pi05_vla_server`` (or any compatible ``vla.predict`` /
``healthz`` implementation) before constructing this client.

Embodiment-specific obs encoding is dispatched by the ``_ENCODE_OBS`` registry.
Add a new encoder function and register it there per embodiment.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from rpent.robots.components.vla_client_base import BaseVLAClient

# ---------------------------------------------------------------------------
# Obs encoder registry
# ---------------------------------------------------------------------------


def _encode_obs_libero(env_obs: dict) -> dict:
    """LIBERO single-env obs → openpi batched wire obs.

    openpi expects ``main_images [B,H,W,3]``, ``wrist_images [B,H,W,3]``
    or ``None``, ``extra_view_images [B,H,W,3]`` or ``None``,
    ``states [B,state_dim] float32``, ``task_descriptions [str]``.
    Images are cast to ``uint8`` (openpi ``Normalize`` expects ``[0,255]``
    uint8 input) and validated to be single ``[H,W,3]`` views.
    """

    def _batch_view(v):
        if v is None:
            return None
        arr = np.asarray(v)
        if arr.ndim != 3:
            raise ValueError(f"expected [H,W,3] image, got shape {arr.shape}")
        return arr.astype(np.uint8)[None]

    main = np.asarray(env_obs["main_images"])
    if main.ndim != 3:
        raise ValueError(f"expected [H,W,3] image, got shape {main.shape}")
    return {
        "main_images": main.astype(np.uint8)[None],
        "wrist_images": _batch_view(env_obs.get("wrist_images")),
        "extra_view_images": _batch_view(env_obs.get("extra_view_images")),
        "states": np.asarray(env_obs["states"], dtype=np.float32)[None],
        "task_descriptions": [str(env_obs.get("task_descriptions") or "")],
    }


def _encode_obs_robodojo(env_obs: dict) -> dict:
    """RoboDojo single-env obs → openpi batched wire obs."""

    def _batch_view(camera: str) -> np.ndarray:
        try:
            value = env_obs["vision"][camera]["color"]
        except (KeyError, TypeError) as exc:
            raise ValueError(f"missing RoboDojo camera: vision/{camera}/color") from exc
        arr = np.asarray(value)
        if arr.ndim != 3 or arr.shape[-1] != 3:
            raise ValueError(f"{camera}: expected [H,W,3] image, got {arr.shape}")
        return arr.astype(np.uint8)[None]

    parts = []
    for key, size in (
        ("left_arm_joint_state", 6),
        ("right_arm_joint_state", 6),
        ("left_ee_joint_state", 1),
        ("right_ee_joint_state", 1),
    ):
        try:
            value = env_obs["state"][key]
        except (KeyError, TypeError) as exc:
            raise ValueError(f"missing RoboDojo state: state/{key}") from exc
        part = np.asarray(value, dtype=np.float32)
        if part.shape != (size,):
            raise ValueError(f"state/{key}: expected shape ({size},), got {part.shape}")
        parts.append(part)
    # Keep observed gripper values: 1.0 is open and 0.0 is closed.
    states = np.concatenate(parts)
    assert states.shape == (14,)
    return {
        "main_images": _batch_view("cam_head"),
        "wrist_images": _batch_view("cam_left_wrist"),
        "extra_view_images": _batch_view("cam_right_wrist"),
        "states": states[None],
        "task_descriptions": [str(env_obs.get("instruction") or "")],
    }


def _batch_views(v):
    """``[H,W,3]`` → ``[1,H,W,3]`` or ``[N,H,W,3]`` → ``[1,N,H,W,3]``.
    Used by the dual-Franka encoder to batch the two extra views (base + right-wrist).
    """
    if v is None:
        return None
    arr = np.asarray(v)
    if arr.ndim == 3:
        return arr.astype(np.uint8)[None]
    if arr.ndim == 4:
        return arr.astype(np.uint8)[None]
    raise ValueError(f"expected [H,W,3] or [N,H,W,3] image, got shape {arr.shape}")


def _encode_obs_franka(env_obs: dict) -> dict:
    """Single-Franka obs → openpi batched wire obs.

    The single-arm rig exposes one main (wrist) camera and one external
    camera, so ``main_images`` is the primary view and ``extra_view_images``
    carries the single external view (if present).
    """
    main = np.asarray(env_obs["main_images"])
    if main.ndim != 3:
        raise ValueError(f"expected [H,W,3] image, got shape {main.shape}")
    states = np.asarray(env_obs["states"], dtype=np.float32)
    if states.ndim != 1:
        raise ValueError(
            f"states must be single-env shape [state_dim]; got {states.shape}"
        )
    return {
        "main_images": main.astype(np.uint8)[None],
        "wrist_images": None,
        "extra_view_images": _batch_views(env_obs.get("extra_view_images")),
        "states": states[None],
        "task_descriptions": [str(env_obs.get("task_descriptions") or "")],
    }


def _encode_obs_dual_franka(env_obs: dict) -> dict:
    """Dual-Franka obs → openpi batched wire obs.

    The rig sends the left-wrist camera as ``main_images`` plus the base and
    right-wrist cameras stacked as two ``extra_view_images`` and a 20-D TCP
    rot6d ``states`` vector.
    """
    main = np.asarray(env_obs["main_images"])
    if main.ndim != 3:
        raise ValueError(f"expected [H,W,3] image, got shape {main.shape}")
    extras = np.asarray(env_obs["extra_view_images"])
    if extras.ndim != 4:
        raise ValueError(
            f"extra_view_images must be [N,H,W,3]; got shape {extras.shape}"
        )
    states = np.asarray(env_obs["states"], dtype=np.float32)
    if states.ndim != 1:
        raise ValueError(
            f"states must be single-env shape [state_dim]; got {states.shape}"
        )
    return {
        "main_images": main.astype(np.uint8)[None],
        "wrist_images": None,
        "extra_view_images": extras.astype(np.uint8)[None],
        "states": states[None],
        "task_descriptions": [str(env_obs.get("task_descriptions") or "")],
    }


def _encode_obs_yam(env_obs: dict) -> dict:
    """Batch one YAM top view, two wrist views, and a qpos14 state."""
    main = np.asarray(env_obs["main_images"])
    extras = np.asarray(env_obs["extra_view_images"])
    states = np.asarray(env_obs["states"], dtype=np.float32)
    description = env_obs.get("task_descriptions")
    if main.ndim != 3 or main.shape[-1] != 3 or main.dtype != np.uint8:
        raise ValueError("YAM main_images must be uint8 RGB [H,W,3]")
    if extras.shape != (2, *main.shape) or extras.dtype != np.uint8:
        raise ValueError(
            "YAM extra_view_images must be uint8 RGB [2,H,W,3], ordered left/right"
        )
    if states.shape != (14,) or not np.isfinite(states).all():
        raise ValueError("YAM states must be finite [14]")
    if not isinstance(description, str) or not description.strip():
        raise ValueError("YAM task_descriptions must be a nonempty instruction")
    return {
        "main_images": main[None],
        "wrist_images": None,
        "extra_view_images": extras[None],
        "states": states[None],
        "task_descriptions": [description],
    }


# NOTE: an embodiment registered here must also exist in the server's
# ``PI05_EMBODIMENTS`` (and ``PI05_ROBOT_PLATFORMS`` if it sets ROBOT_PLATFORM);
# the two registries are kept in sync manually.
_ENCODE_OBS: dict[str, Any] = {
    "libero": _encode_obs_libero,
    "robodojo": _encode_obs_robodojo,
    "franka": _encode_obs_franka,
    "dual_franka": _encode_obs_dual_franka,
    "yam": _encode_obs_yam,
}


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class Pi05VLAClient(BaseVLAClient):
    """Client wrapping a remote Pi0.5 VLA over any :class:`RpcClient` transport.

    Construction requires an ``embodiment`` name (e.g. ``"libero"``) that
    selects the obs encoder from ``_ENCODE_OBS``.
    """

    def __init__(self, client, *, embodiment: str):
        super().__init__(client)
        if embodiment not in _ENCODE_OBS:
            raise ValueError(
                f"unknown pi05 client embodiment: {embodiment!r}; "
                f"registered={list(_ENCODE_OBS)}"
            )
        self._embodiment = embodiment

    # ---- obs encode (symmetric with server decode_obs_<name>) ----

    def encode_obs(self, env_obs: dict) -> dict:
        """Dispatch to the embodiment's encoder from ``_ENCODE_OBS``."""
        return _ENCODE_OBS[self._embodiment](env_obs)

    def status(self, *, timeout_s: float = 10) -> dict[str, Any]:
        """Query prediction chunk length from a server supporting ``vla.status``."""
        return self._client.call("vla.status", timeout_s=timeout_s)

    # ---- inference ----

    def predict(self, env_obs: dict, options: dict | None = None) -> np.ndarray:
        """Encode obs, request ``vla.predict``, strip batch dim, return ``[chunk, action_dim]``."""
        openpi_obs = self.encode_obs(env_obs)
        actions = np.asarray(super().predict(openpi_obs, options))
        return actions[0]
