# E04: VLA contact feedback removed; full native progress retained

160 valid episodes: Seen 29/80, Unseen 15/80, total 44/160 (27.50%).
Only grasp_contact, grasp_obj, grasped and grasp_detected reports are removed.
All native task_progress, native success and VLA success early stop remain. No VLM.

This public audit ZIP contains all results, native states, memory audits, exit
codes, production source and selected analysis. Machine paths are replaced in
JSON/JSONL; production source is byte-identical. Original hashes and public
member hashes are recorded separately. Raw Planner traces, videos, images,
operator logs, credentials, environments, weights and the memory corpus are
not included. Complete raw experiment data remains in its original local folder.

The current E04 replaces the earlier filtered-progress 46/160 result. That
historical run is archived separately and is not included in these 160 episodes.
Baseline references use existing public E01 exports. See analysis/report.md for
comparison limits and extractor inputs; the extractor uses the original run.
